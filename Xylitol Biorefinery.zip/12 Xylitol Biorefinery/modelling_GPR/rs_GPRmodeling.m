clc; clear; close all;
addpath("../simulations")

% read MCS data
cID = 1;  % select configuration
N = 500;
Ti = readtable(sprintf("C%di_%d.csv",cID,N));
To = readtable(sprintf("C%do_%d.csv",cID,N));

% clean data
T = [Ti To];
T = rmmissing(T); % remove NaNs
T = rmoutliers(T,'quartiles'); % remove outliers

% train a GPR model on the entire dataset

%% Objective
X = T{:,Ti.Properties.VariableNames}; % inputs
y = T{:,'NPV'}; % objective

objGPR  = fitrgp(X,y,'OptimizeHyperparameters','all'); % 'BasisFunction' 'KernelFunction' 'KernelScale' 'Sigma' 'Standardize'}
[ypred,ysd,yci] = predict(objGPR,X,'Alpha',0.05); % return 95% CI
objR2  = corr(y,ypred).^2
objRMSE = sqrt(mean((ypred-y).^2))

y = T{:,'CO2_biogen'}; % constraint 1
con1GPR  = fitrgp(X,y,'OptimizeHyperparameters','all');
[ypred,ysd,yci] = predict(con1GPR,X,'Alpha',0.05); % return 95% CI
con1R2  = corr(y,ypred).^2
con1RMSE = sqrt(mean((ypred-y).^2))

y = T{:,'CO2_fossil'}; % constraint 2
con2GPR  = fitrgp(X,y,'OptimizeHyperparameters','all');
[ypred,ysd,yci] = predict(con2GPR,X,'Alpha',0.05); % return 95% CI
con2R2  = corr(y,ypred).^2
con2RMSE = sqrt(mean((ypred-y).^2))

y = T{:,'Xylitol'}; % constraint 3
con3GPR  = fitrgp(X,y,'OptimizeHyperparameters','all');
[ypred,ysd,yci] = predict(con3GPR,X,'Alpha',0.05); % return 95% CI
con3R2  = corr(y,ypred).^2
con3RMSE = sqrt(mean((ypred-y).^2))

% [nX,muX,sigX] = standardize(X);
% [ny,muyObj,sigyObj] = standardize(y);
% 
% objGPR  = fitrgp(nX,ny,'OptimizeHyperparameters','all'); % 'BasisFunction' 'KernelFunction' 'KernelScale' 'Sigma' 'Standardize'}
% [ypred,ysd,yci] = predict(objGPR,nX,'Alpha',0.05); % return 95% CI
% 
% rypred = restandardize(ypred,muyObj,sigyObj);
% objR2  = corr(y,rypred).^2
% objRMSE = sqrt(mean((rypred-y).^2))
% 
% %% Constraint 1
% y = T{:,'Max5HMF'}; % constraint 1
% [ny,muyCon1,sigyCon1] = standardize(y);
% 
% con1GPR  = fitrgp(nX,ny,'OptimizeHyperparameters','all');
% [ypred,ysd,yci] = predict(con1GPR,nX,'Alpha',0.05); % return 95% CI
% 
% rypred = restandardize(ypred,muyCon1,sigyCon1);
% con1R2  = corr(y,rypred).^2
% con1RMSE = sqrt(mean((rypred-y).^2))
% 
% %% Constraint 2
% y = T{:,'MaxAac'}; % constraint 2
% [ny,muyCon2,sigyCon2] = standardize(y);
% 
% con2GPR  = fitrgp(nX,ny,'OptimizeHyperparameters','all');
% [ypred,ysd,yci] = predict(con2GPR,nX,'Alpha',0.05); % return 95% CI
% 
% rypred = restandardize(ypred,muyCon2,sigyCon2);
% con2R2  = corr(y,rypred).^2
% con2RMSE = sqrt(mean((rypred-y).^2))


% %% Constraint 3
% y = T{:,'CO2Ratio'}; % constraint 3
% [ny,muyCon3,sigyCon3] = standardize(y);
% 
% con3GPR  = fitrgp(nX,ny,'OptimizeHyperparameters','all');
% [ypred,ysd,yci] = predict(con3GPR,nX,'Alpha',0.05); % re3urn 95% CI
% 
% rypred = restandardize(ypred,muyCon3,sigyCon2);
% con3R2  = corr(y,rypred).^2
% con3RMSE = sqrt(mean((rypred-y).^2))


save(sprintf("c%d_GPR_%d",cID,N))