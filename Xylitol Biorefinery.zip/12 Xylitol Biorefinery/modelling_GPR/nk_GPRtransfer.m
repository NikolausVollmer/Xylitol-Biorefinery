clear; clc; close all;

outs =  ["NPV", "Xylitol", "Succinic_Acid", "El_Net"];
cID = 2;
Ns = [500];
YPs = [1];

for d=1:length(YPs)
    for e=1:length(Ns)
        for g=1:length(outs)
            yp = YPs(d);
            N = Ns(e);
            out = outs(g);

            load(sprintf("c%d_GPR_%d_cval_%s_VCO_%d",cID,N,out,yp),'myGPR','gprR2','gprRMSE')
            
            if out == "NPV"
                npvGPR = myGPR;
                npvR2 = gprR2;
                npvRMSE = gprRMSE;
            elseif out == "Xylitol"
                xyoGPR = myGPR;
                xyoR2 = gprR2;
                xyoRMSE = gprRMSE;
            elseif out == "Succinic_Acid"
                sucGPR = myGPR;
                sucR2 = gprR2;
                sucRMSE = gprRMSE;
            elseif out == "El_Net"
                pelGPR = myGPR;
                pelR2 = gprR2;
                pelRMSE = gprRMSE;
            end          

        end
        
       save(sprintf("c%d_GPR_%d_opt_VCO_%d",cID,N,yp),'npvGPR','npvR2','npvRMSE',...
                                            'xyoGPR','xyoR2','xyoRMSE',...
                                            'sucGPR','sucR2','sucRMSE',...
                                            'pelGPR','pelR2','pelRMSE');
        
    end
end

        