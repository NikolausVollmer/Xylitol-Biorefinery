clear
close all
clc

addpath("../sampling")
addpath("../models")

rng(42,'twister')

[T, configIDs] = nk_ctable;

cIDs = [2,4,10,18];
N = 1000;

X = [0.3097, 47, 0.07392, 0.9907, 0.5881;
     0.3119, 43.607, 0.85, 0.9896, 0.6;
     0.25, 43.786, 0.85, 0.9892, 0.6;
     0.25, 47.496, 0, 0.995, 0.6];
    

for i=1:length(cIDs) 
    cID = cIDs(i);

    configID = configIDs{cID}; 
    space    = nk_designSpace(configID); show(space);

    %% Sampling with boundary points
    red = reduced_space(cID);

    % Start Aspen
    HF = StartAspen("HF");
    CF = StartAspen("CF");
    LF = StartAspen("LF");
    Aspen = struct("HF", HF, "CF", CF, "LF", LF);

    %  input space
    xr = X(i,:);
    x = space.SetPoints;
    x(red) = xr;

    % run simulation
    [KPI0,Mass0] = nk_runfse_mass(x,space,configID,Aspen)
    
    % close aspen
    CloseAspen(CF);
    CloseAspen(HF);
    CloseAspen(LF);
    clear Aspen CF HF LF

    mcsfolder = sprintf('c%d_mcsims',cID); % name of the folder where for iters are stored
    if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end
    
    %% Distributions
    FCIdist = makedist('Triangular','a',0.5,'b',1,'c',2);
    FCIX = random(FCIdist,N,1);
    
    TPCdist = makedist('Triangular','a',0.8,'b',1,'c',1.5);
    TPCX = random(TPCdist,N,1);
    
    xyoprice = [4290, 5420]; % [%]
    Xyodist = makedist('Uniform','Lower',xyoprice(1),'Upper',xyoprice(2));
    XyoX = random(Xyodist,N,1);
    
    sucprice = [3180, 3240]; % [%]
    Sucdist = makedist('Uniform','Lower',sucprice(1),'Upper',sucprice(2));
    SucX = random(Sucdist,N,1);
    
    Xdist = horzcat(FCIX,TPCX,XyoX,SucX);
    
    %% Simulations

    for i=1:N
        try

            fprintf('Configuration ID %d, started run %d. ',cID,i);
            filename = fullfile(mcsfolder, sprintf('row%d',i));
            if exist(filename,'file')==2
                continue;
            end
            
            xdist = Xdist(i,:);
            
            [KPI,Mass] = nk_runfse_kpi(KPI0,Mass0,xdist)
            
            m=matfile(filename,'writable',true); m.KPI=KPI; m.Mass=Mass;
            fprintf('Finished a successful run.\n')

        catch ME
            fprintf('Hit an error.\n')
            rethrow(ME)
        end
    end


    % collect completed sims
    for i=1:N
        try
            filename = fullfile(mcsfolder, sprintf('row%d',i));
            m=matfile(filename,'writable',true);
            D(i).KPI  = m.KPI;
            D(i).Mass = m.Mass;
        catch ME
            D(i).KPI  = NaN;
            D(i).Mass = NaN;
            %rethrow(ME)
        end
    end


    % Put all KPIs and Masses into a table T
    S = struct;
    fnames = fields(D(1).KPI);
    gnames = fields(D(1).Mass);

    for i=1:numel(D)
        for j=1:numel(fnames)
            try
                S(i).(fnames{j}) = D(i).KPI.(fnames{j});
            catch
                S(i).(fnames{j}) = NaN;
            end
        end

        for j=1:numel(gnames)
            try
                S(i).(gnames{j}) = D(i).Mass.(gnames{j});
            catch
                S(i).(gnames{j}) = NaN;
            end
        end
    end

    To = struct2table(S) % convert to a table        
    Ti = array2table(X,'VariableNames',space.ParNames(red));

    writetable(Ti,sprintf("C%di_%d.csv",cID,N))
    writetable(To,sprintf("C%do_%d.csv",cID,N))

    % Save run
    save(sprintf("c%d_TEA",cID))

end

function red = reduced_space(cID)

red_cID1 = [9,21,25,27,29];
red_cID2 = [7,15,18,20,22];
red_cID3 = [8,19,24,25,27];
red_cID4 = [6,13,17,18,20];

red_cID9 = [9,21,26,27,28];
red_cID10 = [7,15,19,20,21];
red_cID11 = [8,19,23,25,26];
red_cID12 = [6,13,16,18,19];

red_cID17 = [8,19,23,25,27];
red_cID18 = [6,13,16,18,20];
red_cID19 = [7,17,22,23,25];
red_cID20 = [5,11,15,16,18];

red_cID25 = [8,19,24,25,26];
red_cID26 = [6,13,17,18,19];
red_cID27 = [7,17,22,23,24];
red_cID28 = [5,11,14,16,17];

red_0 = [0,0,0,0,0];

red_cID = [red_cID1;red_cID2;red_cID3;red_cID4;
           red_0;red_0;red_0;red_0;
           red_cID9;red_cID10;red_cID11;red_cID12;
           red_0;red_0;red_0;red_0;
           red_cID17;red_cID18;red_cID19;red_cID20;
           red_0;red_0;red_0;red_0;
           red_cID25;red_cID26;red_cID27;red_cID28;
           red_0;red_0;red_0;red_0];


red = red_cID(cID,:);

end

