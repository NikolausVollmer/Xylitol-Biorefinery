function [KPI, Mass] = nk_runfse_kpi(KPI, Mass, xdist)

% Distribution
KPI.FCI = KPI.FCI * xdist(1);
    
%% Total Costs of Installation (CAPEX)
KPI.TCI = total_costs_installation(KPI.FCI);

%% OPEX
[C_VOC, C_FOC, C_sales, KPI] = costing_utilities(Mass.Feedstock, Mass.Acid, Mass.Base, Mass.Nitrogen, Mass.Titrant, Mass.Ethanol, Mass.Enzyme, Mass.CO2_succ_in, Mass.Hydrogen, Mass.Water_Net, Mass.Steam_Net, Mass.Cooling_Makeup, Mass.Ccooling_Makeup, Mass.Flue_Gas_Net, Mass.El_Net, Mass.Xylitol, Mass.Succinic_Acid, Mass.Kerosene, Mass.Brine, Mass.Acid, xdist, KPI);

KPI.TPC = C_VOC + C_FOC;
KPI.TPC = KPI.TPC * xdist(2);
KPI.Sales = C_sales;

%% Key Performance Indicators (KPI)
[ROI, PBP, NPV, DCFR, MSEP] = key_performance_indicators(KPI.TCI, KPI.TPC, KPI.Sales, KPI.FCI, Mass.Xylitol, Mass.Succinic_Acid, Mass.Kerosene);

KPI.ROI = ROI;
KPI.PBP = PBP;
KPI.NPV = NPV;
KPI.DCFR = DCFR;
KPI.MSEP = MSEP;

end

%% Costing Utilities % Products
function [C_utilities, C_FOC, C_sales, KPI] = costing_utilities(m_feedstock, m_acid, m_base, m_nitro, m_titr, m_antisolvent, m_enzyme, m_co2, m_h2, m_net_water, m_net_steam, m_cooling_makeup, m_ccooling_makeup, m_fg_net, P_el_net, m_xylitol, m_succinic_acid, m_kerosene, m_brine, m_ashes, xdist, KPI)
% Prices
p_feedstock = 117.86; % $/t
p_sulfuric_acid = 93; % $/t
p_sodium_hydroxide = 134.43; % $/t
p_enzyme = 2085; % $/t
p_ammonia = 685; % $/t
p_potassium_phosphate = 1268.41; % $/t
p_ethanol = 517; % $/t
p_carbon_dioxide = 50; % $/t
p_hydrogen = 1400; % $/t


p_freshwater = 0.53; % $/t (McGrawHill)
p_cooling = 0.23; % $/t (NREL)
p_ccooling = 3 * p_cooling;
% p_LPsteam = 4.4; % $/t
p_MPsteam = 29.59; % $/t (see excel)
% p_HPsteam = 4.4; % $/t
p_electricity = 0.06; % $/kWh (see excel)
p_fuel_gas = 0.7459; % $/t (see excel)

p_brine = 0.53; % $/t (McGrawHill)
p_ashes = 28.86; % $/t (NREL)

p_xylitol = 6350; % $/t
p_succinic_acid = 2860; % $/t
p_kerosene = 1.3*785.54; % $/t

% Distributions
p_xylitol = xdist(3);
p_succinic_acid = xdist(4);

% Costs ($/y)
C_feedstock = p_feedstock * m_feedstock / 1000;
C_acid = p_sulfuric_acid * m_acid / 1000;
C_base = p_sodium_hydroxide * m_base / 1000;
C_nitro = p_ammonia * m_nitro / 1000;
C_titr = p_potassium_phosphate * m_titr / 1000;
C_antisolvent = p_ethanol * m_antisolvent / 1000;
C_enzyme = p_enzyme * m_enzyme / 1000;
C_carbon_dioxide = p_carbon_dioxide * m_co2 / 1000;
C_hydrogen = p_hydrogen * m_h2 / 1000;

C_water = p_freshwater * abs(m_net_water) / 1000;
C_steam = p_MPsteam * abs(m_net_steam) / 1000;
C_el = p_electricity * abs(P_el_net) * 3600 * 24 * 300 /3.6; % in kWh
C_fg = p_fuel_gas * abs(m_fg_net) / 1000;

C_cooling = p_cooling * m_cooling_makeup / 1000;
C_ccooling = p_ccooling * m_ccooling_makeup / 1000;

C_brine = p_brine * m_brine / 1000;
C_ashes = p_ashes * m_ashes / 1000;

% Fixed Operational expenses (salary etc.)
m_0 = 600e6;
C_FOC_00 = 10.66e6;
n_FOC = 10; % ten years difference
C_FOC_0 = C_FOC_00 * (1+0.01)^n_FOC;
C_FOC = C_FOC_0 * m_feedstock/m_0;

% Sales
C_xylitol = p_xylitol * m_xylitol / 1000;
C_succinic_acid = p_succinic_acid * m_succinic_acid / 1000;
C_kerosene = p_kerosene * m_kerosene / 1000;


C_utilities = C_feedstock + C_acid + C_base + C_nitro + C_titr + C_antisolvent + C_enzyme + C_carbon_dioxide + C_hydrogen + C_water + C_steam + C_el + C_cooling + C_ccooling + C_brine + C_ashes;
C_sales = C_xylitol + C_succinic_acid + C_kerosene;

KPI.VOC_Feedstock = C_feedstock;
KPI.VOC_Acid = C_acid;
KPI.VOC_Base = C_base;
KPI.VOC_Nitro = C_nitro;
KPI.VOC_Titr = C_titr;
KPI.VOC_AS = C_antisolvent;
KPI.VOC_Enzymes = C_enzyme;
KPI.VOC_CO2 = C_carbon_dioxide;
KPI.VOC_Hydrogen = C_hydrogen;
KPI.VOC_Water = C_water;
KPI.VOC_Steam = C_steam;
KPI.VOC_El = C_el;
KPI.VOC_Cooling = C_cooling;
KPI.VOC_Ccooling = C_ccooling;
KPI.VOC_Brine = C_brine;
KPI.VOC_Ashes = C_ashes;
KPI.FOC = C_FOC;


end

%% Total Production Costs
function TCI = total_costs_installation(FCI)
% Total direct costs
TDC = FCI * 1.0788; % 7.88% according to NREL report (basing it on inventory levels)

% Total indirect costs
TIC = TDC * 0.6; % 60% of TDC according to NREL report

% Fixed capital investment
CI = TDC + TIC;

% Total capital investment
TCI = CI * 1.0547; % 5.47% of CI according to NREL report

end

%% Key Performance Indicators (KPI)
function [ROI, PBP, NPV, DCFR, MSEP] = key_performance_indicators(TCI, TPC, Sales, FCI, m_xyo, m_suc, m_ker)
time = 30; % plant life time in years
marr = 0.10; % minimum acceptable rate of return
building_period = 2; % assuming two years building period
MACRS_5 = [0.2, 0.32, 0.192, 0.1152, 0.1152, 0.0576]; % MACRS scheme for 5 years depreciation
MACRS = zeros(time,1); MACRS(2:7) = MACRS_5;
phi = 0.35; % income tax rate

% Return on Investment - ROI
ROI = (Sales - TPC) / TCI * 100; % in percent

% Payback Period - PBP
PBP = FCI / ((Sales - TPC)*(1-phi) + phi * mean(MACRS)); % assuming averaged depreciation

% Net Present Value - NPV
byears = linspace(-building_period, time, time+building_period + 1);
years = linspace(0,time, time+1);

PWF_cf = zeros(1,length(years)); % present worth factor of cash flow per year
PWF_v = zeros(1,length(byears)); % present worth factor of investment per year

for i=1:length(years)
    PWF_cf(i) = (1+marr)^(-years(i));
end

for i=1:length(byears)
    PWF_v(i) = (1+marr)^(-byears(i));
end

MACRS = zeros(1,length(years));
MACRS(1,2:7) = MACRS_5;
TCI_years = zeros(1,length(byears));
TCI_years(1:3) = [0.6*TCI, 0.32*TCI, 0.08*TCI];
rec = zeros(1,length(years)); rec(end) = 0.15*TCI; % recovery

NPV = sum(PWF_cf.*((Sales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum(PWF_v.*TCI_years);

% Discounted Cash Flow of Return - DCFR
fun = @(DCFR) sum((1+DCFR).^(-years) .* ((Sales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum((1+DCFR).^(-byears) .*TCI_years);
x0 = 0;

options = optimoptions('fsolve','Display','off');
DCFR = fsolve(fun,x0,options);

% Minimum Selling Price of Products
fun2 = @(MinSales) sum((1+marr).^(-years) .* ((MinSales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum((1+marr).^(-byears) .*TCI_years);
x0 = 1e8;

options = optimoptions('fsolve','Display','off');
MinSales = fsolve(fun2,x0,options);

p_succinic_acid = 2860; % $/t
p_kerosene = 1.3*785.54; % $/t


MSEP = (MinSales - m_suc/1000*p_succinic_acid - m_ker/1000*p_kerosene)/(m_xyo/1000); % minimum selling price xylitol


end