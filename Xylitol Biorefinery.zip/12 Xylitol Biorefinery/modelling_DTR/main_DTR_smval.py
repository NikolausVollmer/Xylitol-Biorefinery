"""
MAIN

Created on Tue Sep 15 2020
@author: nikov@kt.dtu.dk

Main script for creating piecewise linear surrogate models for superstructure optimization

Routine containing the following files & functions:
main.py
pslm.py
-import
-triangulation
-mesh_reduction
--IEC
-export

"""
## Initialization
from plsm import import_csv, triangulation, mesh_reduction, export_csv
from IEC_functions import barycentric_coordinates
from scipy.spatial import ConvexHull
import numpy as np
from sklearn.metrics import r2_score
import plotly.graph_objects as pgo
import pandas as pd


cIDs = [1,2,3,4,9,10,11,12,17,18,19,20,25,26,27,28]
Ns = [500]
outputs = [6, 9, 10, 29]

out = np.empty((len(cIDs),2*len(outputs)))

for h in range(len(cIDs)):
    for k in range(len(Ns)):
        cID = cIDs[h]
        N = Ns[k]
        print(cID)


        cval = 10
        dim = (5,4)
        error = 0.001

        filepath_in = [r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\simulations\N={}\C{}i_{}.csv'.format(N,cID,N),
                       r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\simulations\N={}\C{}o_{}.csv'.format(N,cID,N)]
        filepath_out = r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\modelling_DTR\C{}_DTR_{}.csv'.format(cID,N)




        ## initialize main dictionary "dictData"
        dictData = dict()
        dictData["error"] = error
        dictData["filepath_in"] = filepath_in
        dictData["outputs"] = outputs

        # dictData["filepath_out"] = filepath_out
        dictData["dim"] = dim

        ## IMPORT Data
        dictData = import_csv(dictData)

        ## TRIANGULATE Data for crossvalidation
        # dictData = triangulation(dictData)
        dictData["X0"] = dictData["X"]
        dictData["Y0"] = dictData["Y"]

        y_calc_tot = list()
        y_calc2_tot = list()
        y_calc3_tot = list()
        y_calc4_tot = list()
        y_pred_tot = list()
        y_pred2_tot = list()
        y_pred3_tot = list()
        y_pred4_tot = list()


        rsqrlist = list()
        rsqr2list = list()
        rsqr3list = list()
        rsqr4list = list()
        rmselist = list()
        rmse2list = list()
        rmse3list = list()
        rmse4list = list()

        for j in range(cval):
            ch = ConvexHull(dictData["X0"])
            chvertices = ch.vertices

            testrange = np.setdiff1d(np.arange(N),chvertices)

            ktest = np.random.choice(testrange,int(0.2*N),replace=False)
            ktrain = np.setdiff1d(np.arange(N),ktest)

            dictData["X"] = dictData["X0"][ktrain,:]
            dictData["Y"] = dictData["Y0"][ktrain,:]
            dictData["indices"] = ktrain

            dictData["tX"] = dictData["X0"][ktest,:]
            dictData["tY"] = dictData["Y0"][ktest,:]

            dictData = triangulation(dictData)


            x_in_s = dictData["triangulation_0"].find_simplex(dictData["tX"])
            y_pred = list()
            y_pred2 = list()
            y_pred3 = list()
            y_pred4 = list()
            for i in range(len(x_in_s)):
                bcc = barycentric_coordinates(dictData["X"][dictData["sindices_0"][x_in_s[i]]],dictData["tX"][i])
                y_pred.append(np.sum(np.multiply(bcc,dictData["Y"][dictData["sindices_0"][x_in_s[i]],0])))
                y_pred2.append(np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][x_in_s[i]],1])))
                y_pred3.append(np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][x_in_s[i]],2])))
                y_pred4.append(np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][x_in_s[i]], 3])))

            y_pred = np.array(y_pred)
            y_pred2 = np.array(y_pred2)
            y_pred3 = np.array(y_pred3)
            y_pred4 = np.array(y_pred4)
            y_calc= dictData["tY"][:,0]
            y_calc2 = dictData["tY"][:,1]
            y_calc3 = dictData["tY"][:,2]
            y_calc4 = dictData["tY"][:,3]

            y_pred_tot.append(y_pred)
            y_pred2_tot.append(y_pred2)
            y_pred3_tot.append(y_pred3)
            y_pred4_tot.append(y_pred4)
            y_calc_tot.append(y_calc)
            y_calc2_tot.append(y_calc2)
            y_calc3_tot.append(y_calc3)
            y_calc4_tot.append(y_calc4)

            rmse = np.sqrt(np.mean(np.square(np.subtract(y_pred, y_calc))))
            rmse2 = np.sqrt(np.mean(np.square(np.subtract(y_pred2, y_calc2))))
            rmse3 = np.sqrt(np.mean(np.square(np.subtract(y_pred3, y_calc3))))
            rmse4 = np.sqrt(np.mean(np.square(np.subtract(y_pred4, y_calc4))))
            rsqr = r2_score(y_calc, y_pred)
            rsqr2 = r2_score(y_calc2, y_pred2)
            rsqr3 = r2_score(y_calc3, y_pred3)
            rsqr4 = r2_score(y_calc4, y_pred4)

            rsqrlist.append(rsqr)
            rsqr2list.append(rsqr2)
            rsqr3list.append(rsqr3)
            rsqr4list.append(rsqr4)
            rmselist.append(rmse)
            rmse2list.append(rmse2)
            rmse3list.append(rmse3)
            rmse4list.append(rmse4)

            # fig = pgo.Figure()
            # fig.add_trace(pgo.Scatter(x=list(range(1, len(y_pred)+1)), y=sorted(y_pred), mode="markers"))
            # fig.add_trace(pgo.Scatter(x=list(range(1, len(y_pred)+1)), y=sorted(y_calc)))
            # fig.show()


        # print("R2_mean_NPV",np.mean(np.array(rsqrlist)))
        # print("RMSE_mean_NPV",np.mean(np.array(rmselist)))
        # print("R2_mean_Xylitol",np.mean(np.array(rsqr2list)))
        # print("RMSE_mean_Xylitol",np.mean(np.array(rmse2list)))
        # print("R2_mean_Succinic_Acid",np.mean(np.array(rsqr3list)))
        # print("RMSE_mean_Succinic_Acid",np.mean(np.array(rmse3list)))
        # print("R2_mean_El_Net",np.mean(np.array(rsqr4list)))
        # print("RMSE_mean_El_Net",np.mean(np.array(rmse4list)))

        out[h,] = [np.mean(np.array(rsqrlist)), np.mean(np.array(rmselist)),
                   np.mean(np.array(rsqr2list)), np.mean(np.array(rmse2list)),
                   np.mean(np.array(rsqr3list)), np.mean(np.array(rmse3list)),
                   np.mean(np.array(rsqr4list)), np.mean(np.array(rmse4list))]


dfout = pd.DataFrame(out, index=cIDs, columns=["R2_NPV", "RMSE_NPV", "R2_Xylitol", "RMSE_Xylitol", "R2_Succinic_Acid", "RMSE_Succinic_Acid", "R2_El_Net", "RMSE_El_Net"])
dfout.to_csv(r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\modelling_DTR\DTR_cval_{}.csv'.format(N))
## REDUCE Mesh
# dictData = mesh_reduction(dictData)

## EXPORT Data
# export_csv(dictData)

# y_pred_tot = np.array(y_pred_tot)
# y_calc_tot = np.array(y_calc_tot)
#
# print(y_pred_tot.shape)
# y_pred_mean = np.mean(y_pred_tot, axis=0)
# y_calc_mean = np.mean(y_calc_tot, axis=0)

# fig = pgo.Figure()
# fig.add_trace(pgo.Scatter(x=list(range(1, len(y_pred) + 1)), y=sorted(y_pred_mean), mode="markers"))
# fig.add_trace(pgo.Scatter(x=list(range(1, len(y_pred) + 1)), y=sorted(y_calc_mean)))
# fig.show()