"""
MAIN

Created on Tue Sep 15 2020
@author: nikov@kt.dtu.dk

Main script for creating piecewise linear surrogate models for superstructure optimization

Routine containing the following files & functions:
main.py
pslm.py
-import
-triangulation
-mesh_reduction
--IEC
-export

"""
## Initialization
from plsm import import_csv, triangulation, mesh_reduction, export_csv
from IEC_functions import barycentric_coordinates
import numpy as np

filepath_in = [r'M:\4 Modelling\2 Framework\6 Superstructure Optimization\C2i_LHSb_1000.csv',
               r'M:\4 Modelling\2 Framework\6 Superstructure Optimization\C2o_LHSb_1000.csv']
filepath_out = r'M:\4 Modelling\2 Framework\6 Superstructure Optimization\C2hsn_LHSb_1000.csv'
dim = (5,4)
error = 0.001


## initialize main dictionary "dictData"
dictData = dict()
dictData["error"] = error
dictData["filepath_in"] = filepath_in
dictData["filepath_out"] = filepath_out
dictData["dim"] = dim

## IMPORT Data
dictData = import_csv(dictData)

## TRIANGULATE Data
dictData = triangulation(dictData)

## REDUCE Mesh
# dictData = mesh_reduction(dictData)
x = np.array([0.9078, 1.769, 42.588, 0.9975, 0.4778])
sx = dictData["triangulation_0"].find_simplex(x)
bcc = barycentric_coordinates(dictData["X"][dictData["sindices_0"][sx]], x)
# print(bcc, dictData["Y"][dictData["sindices_0"][x_in_s[i]],0])
y0_pred = np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][sx], 0]))
print(y0_pred)
y1_pred = np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][sx], 1]))
print(y1_pred)
y2_pred = np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][sx], 2]))
print(y2_pred)
y3_pred = np.sum(np.multiply(bcc, dictData["Y"][dictData["sindices_0"][sx], 3]))
print(y3_pred)

## EXPORT Data
# export_csv(dictData)
