"""
MAIN

Created on Tue Sep 15 2020
@author: nikov@kt.dtu.dk

Main script for creating piecewise linear surrogate models for superstructure optimization

Routine containing the following files & functions:
main.py
pslm.py
-import
-triangulation
-mesh_reduction
--IEC
-export

"""
## Initialization
from plsm import import_csv, triangulation, mesh_reduction, export_csv
import numpy as np


cID = 2
N = 500
Ys = [1]
outputs = [6, 9, 10, 29]

out = np.empty((len(Ys),2*len(outputs)))

for yp in Ys:
        filepath_in = [r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\valuechain_optimization\C{}i_{}_VCO_{}.csv'.format(cID,N,yp),
                       r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\valuechain_optimization\C{}o_{}_VCO_{}.csv'.format(cID,N,yp)]
        filepath_out = r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\modelling_DTR\C{}_DTR_{}_VCO_{}.csv'.format(cID,N,yp)
        dim = (6,4)
        error = 0.001


        ## initialize main dictionary "dictData"
        dictData = dict()
        dictData["error"] = error
        dictData["filepath_in"] = filepath_in
        dictData["filepath_out"] = filepath_out
        dictData["dim"] = dim
        dictData["outputs"] = outputs

        ## IMPORT Data
        dictData = import_csv(dictData)

        ## TRIANGULATE Data
        dictData = triangulation(dictData)

        ## REDUCE Mesh
        # dictData = mesh_reduction(dictData)

        ## EXPORT Data
        export_csv(dictData)
