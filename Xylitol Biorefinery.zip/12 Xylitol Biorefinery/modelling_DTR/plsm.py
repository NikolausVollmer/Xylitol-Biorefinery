"""
PIECEWISE LINEAR SURROGATE MODELS

Created on Wed Sep 16 2020
@author: nikov@kt.dtu.dk

File containing functions for the algorithm to create piecewise linear surrogate models by triangulation
and subsequent mesh reduction by incremental edge contraction based on quadric error metrics and external error calculation

Functions:
- import_csv
- Export
- Triangulation - "triangulation"
- MeshReduction - "mesh_reduction"
-- Incremental Edge Contraction
## Error Calculation
## Retessellation
"""
import numpy as np
import pandas as pd
from scipy.spatial import Delaunay, ConvexHull
from IEC import categorize_mesh, quadric_coefficients, contract_edge, calculate_error


## IMPORT function
def import_csv(dictData):
    filepath1 = dictData["filepath_in"][0]
    filepath2 = dictData["filepath_in"][1]
    dim = dictData["dim"]

    frame1 = pd.read_csv(filepath1)
    frame2 = pd.read_csv(filepath2)

    # read data from csv file: indices, input (X), output for objective(Y), output for constraints(C)
    setx = frame1.to_numpy()[:, :dim[0]]
    sety = frame2.to_numpy()[:, dictData["outputs"]]
    indices = np.arange(len(setx))

    # store data in dictionary
    dictData["indices"] = indices
    dictData["X"] = setx
    dictData["Y"] = sety


    return dictData

## EXPORT function
def export_csv(dictData):
    filepath = dictData["filepath_out"]
    # simplices = dictData["ysimplices_0"]
    simplices = dictData["sindices_0"]

    # for i in range(len(simplices)):
    #     if i == 0:
    #         exparray = simplices[i,:,:]
    #     else:
    #         exparray = np.vstack((exparray,simplices[i,:,:]))

#    test = np.reshape(simplices,(simplices.shape[0]*simplices.shape[1],simplices.shape[2]))

    # pd.DataFrame(exparray).to_csv(filepath)
    pd.DataFrame(simplices).to_csv(filepath)

    return


## TRIANGULATION function
def triangulation(dictData):
    data = dictData["X"]
    prediction = dictData["Y"]
    xy = np.hstack((data,prediction))


    # triangulate input data with Delaunay function, obtain simplices and convex hull
    tridata = Delaunay(data)
    dictData["triangulation_0"] = tridata

    # assign vertices to dictData
    dictData["vindices_0"] = list(range(len(data)))
    dictData["vertices_0"] = data
    dictData["yvertices_0"] = xy

    # assign simplices to dictData
    dictData["sindices_0"] = tridata.simplices
    # dictData["simplices_0"] = data[tridata.simplices]
    # dictData["ysimplices_0"] = xy[tridata.simplices]

    # create simplices with attribute

    # predicion values
    dictData["prediction_0"] = prediction

    return dictData

## MESH REDUCTION function
def mesh_reduction(dictData):
    # create instance of simplices, vertices and triangulation for loop
    dictData["sindices"] = dictData["sindices_0"]
    dictData["simplices"] = dictData["simplices_0"]
    dictData["ysimplices"] = dictData["ysimplices_0"]

    dictData["vindices"] = dictData["vindices_0"]
    dictData["vertices"] = dictData["vertices_0"]
    dictData["yvertices"] = dictData["yvertices_0"]

    dictData["prediction"] = dictData["prediction_0"]

    dictData["triangulation"] = dictData["triangulation_0"]

    # initialize variables for loop
    error = dictData["error"]
    rmsqrn = 0.
    loop = 0

    # loop for incremental edge contraction
    while rmsqrn <= error:
        try:
            loop += 1

            # 1. Categorize mesh
            dictMesh = categorize_mesh(dictData)

            # 2. Calculate quadrics quadrics
            A_e, b_e, c_e = quadric_coefficients(dictData, dictMesh)

            # 3. Contract edge based on minimum quadric for new vertex
            vertex_new, yvertex_new, eindex_old, prediction_new = contract_edge(dictData, dictMesh, A_e, b_e, c_e)

            # 4. Delete old vertices, create new triangulation
            if loop == 1:
                old_vertices = dictData["vertices"][[eindex_old[0],eindex_old[1]],:]
                old_attributes = dictData["prediction"][[eindex_old[0],eindex_old[1]],:]
            else:
                old_vertices = np.append(old_vertices,dictData["vertices"][[eindex_old[0],eindex_old[1]],:], axis=0)
                old_attributes = np.append(old_attributes,dictData["prediction"][[eindex_old[0],eindex_old[1]],:], axis=0)

            reduced_vertices = np.delete(dictData["vertices"],[eindex_old[0],eindex_old[1]],0)
            reduced_vertices = np.append(reduced_vertices,[vertex_new], axis=0)
            reduced_yvertices = np.delete(dictData["yvertices"],[eindex_old[0],eindex_old[1]],0)
            reduced_yvertices = np.append(reduced_yvertices,[yvertex_new], axis=0)
            reduced_vindices = list(range(len(reduced_vertices)))

            reduced_prediction = np.delete(dictData["prediction"],[eindex_old[0],eindex_old[1]],0)
            reduced_prediction = np.append(reduced_prediction,[[prediction_new]], axis=0)

            # for i in range(len(reduced_yvertices)):
            #     print(reduced_yvertices[i], reduced_prediction[i])

            reduced_triangulation = Delaunay(reduced_vertices)
            reduced_sindices = reduced_triangulation.simplices
            reduced_simplices = reduced_vertices[reduced_triangulation.simplices]

            dictReduced = dict()
            dictReduced["vertices"] = reduced_vertices
            dictReduced["yvertices"] = reduced_yvertices
            dictReduced["vindices"] = reduced_vindices
            dictReduced["sindices"] = reduced_sindices
            dictReduced["simplices"] = reduced_simplices
            dictReduced["triangulation"] = reduced_triangulation
            dictReduced["prediction"] = reduced_prediction

            # 5. Calculate error
            rmsqr, rmsqrn = calculate_error(dictData, dictReduced, old_vertices, old_attributes)

            if rmsqrn < error:
                print("Error is ", rmsqrn, ", loop ", loop, ", original data points ", len(dictData["vertices_0"]), ", removed data points ", len(old_vertices), ", remaining data points ", len(reduced_vertices))
                dictData["sindices"] = dictReduced["sindices"]
                dictData["simplices"] = dictReduced["simplices"]

                dictData["vindices"] = dictReduced["vindices"]
                dictData["vertices"] = dictReduced["vertices"]
                dictData["yvertices"] = dictReduced["yvertices"]

                dictData["triangulation"] = dictReduced["triangulation"]
                dictData["prediction"] = dictReduced["prediction"]

            else:
                print("Error is ", rmsqrn, ", loop ", loop, ", original data points ", len(dictData["vertices_0"]),
                      ", removed data points ", len(old_vertices), ", remaining data points ", len(reduced_vertices))
                print("Iteration ended in loop ", loop, " with error ", rmsqrn, " due to no remaining contractable edges with given error ", error)

                break

            # rmsqrn += 1

        except ValueError as ve:
            print(ve)
            print("Iteration ended in loop ", loop, " with error ", rmsqrn,
                  " with no remaining contractable edges due to geometric preservation")

            break

    return dictData