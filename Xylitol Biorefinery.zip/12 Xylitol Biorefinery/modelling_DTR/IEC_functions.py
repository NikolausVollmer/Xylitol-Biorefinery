"""
Created on Wed Sep 23 2020
@author: nikov@kt.dtu.dk

File containing functions for the mesh reduction to incrementally contract edges based on quadric error metrics and an
externally calculated error

"""
import numpy as np
import itertools
from collections import Counter, defaultdict
import copy
from scipy.interpolate import interp1d
from scipy.linalg import orth

# basic functions
def calculate_base(simplex):
    shape = simplex.shape
    baselist = list()

    for i in range(1,shape[0]):
        base_row = simplex[i] - simplex[0]
        baselist.append(list(base_row))

    baselist = np.array(baselist)

    return baselist

def gram_schmidt(base):
    obaselist = list()

    for v in base:
        w = v - np.sum(np.dot(v,b)*b  for b in obaselist)

        if np.linalg.norm(w) < 1e-5:
            obaselist.append(w)
        else:
            obaselist.append(w/np.linalg.norm(w))

    obaselist = np.array([ob.tolist() for ob in obaselist])

    return obaselist

def barycenter(simplex):
    shape = simplex.shape
    bc = 1.0/(shape[0]) * np.sum(simplex, axis=0)

    return bc

def calculate_weight(ysimplex):
    ybase = calculate_base(ysimplex)
    ydim = len(ybase)
    yw = (1. / np.math.factorial(ydim)) * np.sqrt(np.linalg.det(np.dot(ybase,ybase.T)))

    return yw

def barycentric_coordinates(simplex, vertex):
    A = simplex[:] - vertex
    A = np.hstack((A,np.ones((simplex.shape[0],1))))

    b = np.zeros(simplex.shape[1])
    b = np.append(b, [1.])

    bcc = np.linalg.solve(A.T,b)

    return bcc

def quadrics_Abc(simplex,ysimplex,dim):
    # 1. Calculate base and orthogonal base of simplex
    base = calculate_base(ysimplex)
    # orthogonal_base = gram_schmidt(base)
    q,r = np.linalg.qr(base.T)
    orthogonal_base = q.T

    # 2. Calculate barycenter and weight of simplex
    p = barycenter(ysimplex)
    print(ysimplex,p)
    I = np.eye(dim[0]+1)

    weight = calculate_weight(ysimplex)

    #3. Quadric coefficients A,b,c

    A = np.subtract(I, np.sum(np.outer(ob,ob) for ob in orthogonal_base))
    b = -np.dot(A,p)
    c = np.dot(p.T,np.dot(A,p))

    A = A * weight/(1+len(base))
    b = b * weight/(1+len(base))
    c = c * weight/(1+len(base))

    return A, b, c
