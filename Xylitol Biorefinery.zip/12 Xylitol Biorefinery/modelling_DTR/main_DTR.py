"""
MAIN

Created on Tue Sep 15 2020
@author: nikov@kt.dtu.dk

Main script for creating piecewise linear surrogate models for superstructure optimization

Routine containing the following files & functions:
main.py
pslm.py
-import
-triangulation
-mesh_reduction
--IEC
-export

"""
## Initialization
from plsm import import_csv, triangulation, mesh_reduction, export_csv


cIDs = [1,3,4,9,11,12,17,19,20,25,27,28]
Ns = [500]
outputs = [6, 9, 10, 29]
#
for cID in cIDs:
   for N in Ns:
        filepath_in = [r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\simulations\N={}\C{}i_{}.csv'.format(N,cID,N),
                       r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\simulations\N={}\C{}o_{}.csv'.format(N,cID,N)]
        filepath_out = r'M:\4 Modelling\2 Framework\11 Base-Case Process Design\modelling_DTR\C{}_DTR_{}.csv'.format(cID,N)
        dim = (5,4)
        error = 0.001


        ## initialize main dictionary "dictData"
        dictData = dict()
        dictData["error"] = error
        dictData["filepath_in"] = filepath_in
        dictData["filepath_out"] = filepath_out
        dictData["dim"] = dim
        dictData["outputs"] = outputs

        ## IMPORT Data
        dictData = import_csv(dictData)

        ## TRIANGULATE Data
        dictData = triangulation(dictData)

        ## REDUCE Mesh
        # dictData = mesh_reduction(dictData)

        ## EXPORT Data
        export_csv(dictData)
