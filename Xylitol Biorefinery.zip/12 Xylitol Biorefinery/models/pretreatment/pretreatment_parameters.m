function par = pretreatment_parameters()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Frequency factors
A_Xyn_Xyl = 72.492; %1/s
A_Cel_Glu = 8.3404e-9; %1/s
A_Arn_Ara = 2.8249e-5; %1/s
A_Act_Aac = 1.8263e-7; %1/s
A_Glu_HMF = 6.6523e-5; %1/s
A_HMF_Fac = 1.7066e-7; %1/s
A_Fur = 2.1498e-9; %1/s
A_Deg = 2.914e-8; %1/s

% Activation energies
E_Xyn_Xyl = 121.29; %kJ/mol
E_Cel_Glu = 39.246; %kJ/mol
E_Arn_Ara = 56.974; %kJ/mol
E_Act_Aac = 38.661; %kJ/mol
E_Glu_HMF = 66.419; %kJ/mol
E_HMF_Fac = 38.038; %kJ/mol
E_Fur = 26.089; %kJ/mol
E_Deg = 37.349; %kJ/mol

% Reaction order
n_Xyn_Xyl = 1.3029; %-
n_Cel_Glu = 0.45938; %-
n_Arn_Ara = 0.77198; %-
n_Act_Aac = 0.9038; %-
n_Glu_HMF = 0.44371; %-
n_HMF_Fac = 1.2807; %-
n_Fur = 0.042991; %-
n_Deg = 0.46321;

par = [A_Xyn_Xyl, A_Cel_Glu, A_Arn_Ara, A_Act_Aac, A_Glu_HMF, A_HMF_Fac, A_Fur, A_Deg,...
       E_Xyn_Xyl, E_Cel_Glu, E_Arn_Ara, E_Act_Aac, E_Glu_HMF, E_HMF_Fac, E_Fur, E_Deg,...
       n_Xyn_Xyl, n_Cel_Glu, n_Arn_Ara, n_Act_Aac, n_Glu_HMF, n_HMF_Fac, n_Fur, n_Deg];

end

