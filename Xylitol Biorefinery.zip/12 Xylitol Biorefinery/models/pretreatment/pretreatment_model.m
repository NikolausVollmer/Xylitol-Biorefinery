function [m_hydrolyzate,c_out_hydrolyzate,m_residual,c_out_residual, mf, hf, design] = pretreatment_model(m_biomass,c_in,stats)
%% Pretreatment model
%   Detailed explanation goes here

% Parameters
% Frequency factors, activation energies, reaction orders
par = pretreatment_parameters();

% State variables
% 1. Temperature T
% 2. Concentration of sulfuric acid (H2SO4) ac
% other state variables are taken out of the vector

time = stats(1);
phi = stats(4);
stats = stats([2,3]);

% Input masses
m = feed_mass_pretreatment(m_biomass,phi,stats(2));
m_biomass_dry = m(1);
m_water = m(2);
m_acid_dry = m(3);
m_water_add = m(4);
m_acid_add = m(5);

% Time
% Time of residence
tspan = linspace(0,time,100);

%% Reaction
options = odeset('RelTol',1e-7,'AbsTol',1e-8);
[~,y] = ode45(@pretreatment_kinetics,tspan,c_in(1:12),options,par,stats);


%% Output masses
% c_out based on 100g biomass dry
c_res = y(end,:);
c_res = [c_res, c_in(13:20)];

% absolute mass of components
m_res = c_res * m_biomass_dry/100;

% output masses of hydrolyzate and residue
[m_hydrolyzate,c_out_hydrolyzate,m_residual,c_out_residual] = output_mass_pretreatment(m_res, m_water, m_acid_dry);

% energy balance
[H_heat, H_cool] = pretreatment_energy_balance(m_biomass_dry, m_water, m_acid_dry, stats);

% Sizing
V_Reactor = sizing_pretreatment(m_biomass_dry, time);


% Mass flows
mf(1) = m_water_add;
mf(2) = m_acid_add;

% Enthalpy flows
hf = [H_heat, H_cool];

% Costing
FCI = costing_pretreatment(m_biomass);

design = [V_Reactor, FCI];


end

%% Calculation of feed mass
function m = feed_mass_pretreatment(m_biomass, phi, ac)

% a) m_total = m_biomass + m_water + m_acid
% where m_biomass = m_biomass_dry + phi * m_biomass_dry, with phi =
% humidity in %/100
% b) m_total = 10 * m_biomass_dry, as pretreatment works with a solid/liquid
% fraction of 1:10

% a)
m_biomass_dry = m_biomass / (1 + phi); % [kg]
m_water_in_biomass = m_biomass - m_biomass_dry;

% b)
m_total = 10 * m_biomass_dry;

% The required acid concentration is equivalent to the used percentage
% multiplied by the total mass, assuming that 96% sulfuric acid is used and
% the rest is pure water
m_acid_dry = ac/100 * m_total;
m_acid_add = m_acid_dry * 1/0.96;
m_water_in_acid = m_acid_add - m_acid_dry;

% The required water for the solid liquid fraction and the used acid equals
% the total mass minus the used acid and the biomass
m_water = m_total - m_acid_dry - m_biomass_dry;

% the water which needs to be added is the total amount minus acid and
% biomass and minus the water in the acid and in the biomass
m_water_add = m_water - m_water_in_acid - m_water_in_biomass;

% the total mass of wet biomass, water and acid
% m_total = m_biomass + m_water_add + m_acid_add

m = [m_biomass_dry, m_water, m_acid_dry, m_water_add, m_acid_add];
end

%% Calculation of output mass
function [m_hydrolyzate,c_out_hydrolyzate,m_residual,c_out_residual] = output_mass_pretreatment(m_res, m_water, m_acid_dry)
% mass of solid residues of the biomass
% assuming a residual humidity after phase separation
% assuming an ideally mixed hydrolyzate exists
m_solid_dry = sum(m_res([1,3,5,7,9,13]));

phi = 0.5; % humidity of residual

m_residual_water = m_solid_dry * (1+phi); % water in residual
wfrac = m_residual_water / m_water; % fraction of water in residual
m_residual_acid = wfrac * m_acid_dry; % acid in residual

m_res_residual = m_res; % all solids in residual
m_res_residual([2,4,6,8,9,10,11,12]) = m_res([2,4,6,8,9,10,11,12]) .* wfrac; % liquid fraction in residual
m_res_residual(17) = m_residual_water; % fraction of water in residual
m_res_residual(14) = m_residual_acid; % fraction of acid in residual

m_residual = sum(m_res_residual);

% mass of hydrolyzate
m_hydrolyzate_water = m_water - m_residual_water;
m_hydrolyzate_acid = m_acid_dry - m_residual_acid;

m_res_hydrolyzate = zeros(1,20); % no solids in hydrolyzate
m_res_hydrolyzate([2,4,6,8,9,10,11,12])  = m_res([2,4,6,8,9,10,11,12]) .* (1 - wfrac); % remaining fraction in hydrolyzate
m_res_hydrolyzate(17) = m_hydrolyzate_water; % remanining fraction of water in hydrolyzate
m_res_hydrolyzate(14) = m_hydrolyzate_acid; % remaining fraction of acid in hydrolyzate
m_hydrolyzate = sum(m_res_hydrolyzate);

% outlet concentrations
c_out_residual = m_res_residual ./ m_residual .* 100;
c_out_hydrolyzate = m_res_hydrolyzate ./ m_hydrolyzate .*100;

end

%% ENERGY Balance
function [H_heat, H_cool] = pretreatment_energy_balance(m_biomass_dry, m_water, m_acid_dry, stats)
c_p = 3.8;      % heat capacity of biomass/water/acid mixture in kJ/kg/K
Cp_H2O = 4.19;   % heat capacity of water in kJ/kg/K
Cp_WS = 1.61;    % heat capacity of wheat straw in kJ/kg/K
Cp_acid = 1.38;  % heat capacity of sulfuric acid in kJ/kg/K
T0 = 298.15;    % initial temperature of 25 degC

H_heat = (m_biomass_dry * Cp_WS + m_water * Cp_H2O + m_acid_dry * Cp_acid) * (stats(1) + 273.15 - T0); % Enthalpy for heating from 25degC
H_cool = (m_biomass_dry * Cp_WS + m_water * Cp_H2O + m_acid_dry * Cp_acid) * (T0 + 15 - (stats(1) + 273.15)); % Enthalpy for cooling to 40degC

end

%% SIZING
function V_Reactor = sizing_pretreatment(m_biomass_dry, time)

m_biomass_dry = m_biomass_dry / 1000; % biomass in t

% Densities
rho_straw = 0.1; % t/m3
rho_water = 1;   % t/m3

% Volumetric capacity per hour
m_daily = m_biomass_dry / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

m_total_hourly = 10 * m_hourly; % assuming a solid liquid ration of 1:10 [t/h]
 
% V_total_hourly = 2 * m_total_hourly; % based on experimental values, where 300g correspond to 600mL reactor volume [m3/h]
V_total_hourly = m_hourly / rho_straw + 9 * m_hourly / rho_water;

% Number and volume of reactors to satisfy capacity
V_Reactor = V_total_hourly / (60/time); % assuming a reactor with constant throughput (extruder-like, Prunescu et al. (2014)), with given residence time

end

%% Costing
function FCI = costing_pretreatment(m_biomass)

% Capacity own plant
CP = m_biomass/1e3; % t/y

% Capacity NREL Plant
CP0 = 772575.3; % t/y

% Fixed capital investment for unit
FCI00 = 19e6; % $(2010)
n = 10; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.66; % extrapolation factor, based on other reaction systems

FCI = FCI0 * (CP/CP0)^x;


end
