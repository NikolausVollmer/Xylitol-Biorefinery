function par = hydrolysis_parameters()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

K1 = 0.0027;
K2 = 3.4e-4;
K3 = 0.0053;
K4 = 0.07;

E_M_1 = 0.01;
E_M_2 = 0.015;
E_M_3 = 0.01;

K_ads_1 = 0.1;
K_ads_2 = 0.84;
K_ads_3 = 0.1;

I_Xyl_1 = 201;
I_Cel_1 = 24.3;
I_Glu_1 = 2.39;
I_Fur_1 = 10;

I_Xyl_2 = 0.1007;
I_Cel_2 = 0.0014;
I_Glu_2 = 0.073;
I_Fur_2 = 10;

I_Xyl_3 = 0.029;
I_Cel_3 = 132;
I_Glu_3 = 0.34;
I_Fur_3 = 10;

I_4 = 24.3;
I_Xyl_4 = 201;
I_Glu_4 = 3.9;
I_Fur_4 = 10;


par = [K1, K2, K3, K4, E_M_1, E_M_2, E_M_3, K_ads_1, K_ads_2, K_ads_3, ...
    I_Xyl_1, I_Cel_1, I_Glu_1, I_Fur_1, I_Xyl_2, I_Cel_2, I_Glu_2, I_Fur_2, ...
    I_Xyl_3, I_Cel_3, I_Glu_3, I_Fur_3, I_4, I_Xyl_4, I_Glu_4, I_Fur_4];
end

