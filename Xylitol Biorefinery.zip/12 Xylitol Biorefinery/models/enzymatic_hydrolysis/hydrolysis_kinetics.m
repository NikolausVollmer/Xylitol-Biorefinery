function dydt = hydrolysis_kinetics(t,y,par,stats)
%ENZYMATIC HYDROLYSIS MODEL
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 29.04.2020
%  Detailed explanation

% State variables
T = stats(1);
pH = stats(2);

% Concentrations j of substances
C_Xyn = y(1); % Xylan (Xyn) 
C_Xyl = y(2); % Xylose (Xyl)
C_Cel = y(3); % Cellulose (Cel)
C_Clb = y(4); % Cellobiose (Clb)
C_Glu = y(5); % Glucose (Glu)
C_Fur = y(6); % Furfural (Fur)
C_E1f = y(7); % Enzymes for r1 - free
C_E1b = y(8); % Enzymes for r1 - bound
C_E2f = y(9); % Enzymes for r2,3 - free
C_E2b = y(10); % Enzymes for r2,3 - bound
C_E3f = y(11); % Enzymes for r3,4 - free
C_E3b = y(12); % Enzymes for r3,4 - bound

% Parameters
K1 = par(1);
K2 = par(2);
K3 = par(3);
K4 = par(4);

E_M_1 = par(5);
E_M_2 = par(6);
E_M_3 = par(7);

K_ads_1 = par(8);
K_ads_2 = par(9);
K_ads_3 = par(10);

I_Xyl_1 = par(11);
I_Cel_1 = par(12);
I_Glu_1 = par(13);
I_Fur_1 = par(14);

I_Xyl_2 = par(15);
I_Cel_2 = par(16);
I_Glu_2 = par(17);
I_Fur_2 = par(18);

I_Xyl_3 = par(19);
I_Cel_3 = par(20);
I_Glu_3 = par(21);
I_Fur_3 = par(22);

I_4 = par(23);
I_Xyl_4 = par(24);
I_Glu_4 = par(25);
I_Fur_4 = par(26);

% Calculation of eta
% temperature term of eta
if T <= 52.5
    eta_T = -1e-5*T^6 + 0.0026*T^5 - 0.2538*T^4 + 13.279*T^3 - 387.6*T^2 + 5984.6*T - 38168;
else
    eta_T = -5e-5*T^6 + 0.0195*T^5 - 2.9262*T^4 + 233.97*T^3 - 10494*T^2 + 250388*T - 2e6;
end
    
eta_T = eta_T/100;
    
% pH term of eta
if pH <= 5
    eta_pH = 5.3486*pH^6 - 111.24*pH^5 + 936.31*pH^4 - 4078.1*pH^3 + 9704.6*pH^2 - 11983*pH + 6026.5;
else
    eta_pH = 0.7833*pH^6 - 32.56*pH^5 + 557.66*pH^4 - 5035*pH^3 + 25268*pH^2 - 66843*pH + 72968;
end

eta_pH = eta_pH/100;

% total eta
eta = eta_T * eta_pH;

% Reaction equations rho_i
% 1 - Xylan to Xylose
% 2 - Cellulose to Cellobiose
% 3 - Cellulose to Glucose
% 4 - Cellobiose to Glucose
% 5 - Adsorption E1
% 6 - Adsorption E2
% 7 - Adsorption E3

rho(1,1) = K1 * eta * C_E1b * C_Xyn / (1 + C_Xyl/I_Xyl_1 + C_Cel/I_Cel_1 + C_Glu/I_Glu_1 + C_Fur/I_Fur_1);
rho(2,1) = K2 * eta * C_E2b * C_Cel / (1 + C_Xyl/I_Xyl_2 + C_Cel/I_Cel_2 + C_Glu/I_Glu_2 + C_Fur/I_Fur_2);
rho(3,1) = K3 * eta * (C_E2b + C_E3b) * C_Cel / (1 + C_Xyl/I_Xyl_3 + C_Cel/I_Cel_3 + C_Glu/I_Glu_3 + C_Fur/I_Fur_3);
rho(4,1) = K4 * eta * C_E3f * C_Clb / (I_4*(1 + C_Xyl/I_Xyl_4 + C_Glu/I_Glu_4 + C_Fur/I_Fur_4) + C_Clb);
rho(5,1) = E_M_1 * K_ads_1 * C_E1f / (1 + K_ads_1 * C_E1f) * C_Xyn; % = C_E1_b_onXyn 
rho(6,1) = E_M_2 * K_ads_2 * C_E2f / (1 + K_ads_2 * C_E2f) * C_Cel; % = C_E2_b_onCel 
rho(7,1) = E_M_3 * K_ads_3 * C_E3f / (1 + K_ads_3 * C_E3f) * C_Cel; % = C_E3_b_onCel


% Stoichiometric matrix S_i_j
S = zeros(7,12);
S(1,1) = -1; S(2,1) = 1.136;
S(2,3) = -1; S(2,4) = 1.056;
S(3,3) = -1; S(3,5) = 1.112;
S(4,4) = -1; S(4,5) = 1.053;
S(5,7) = -1; S(5,8) = 1;
S(6,9) = -1; S(6,10) = 1;
S(7,11) = -1; S(7,12) = 1;


% Components & Component Balances r_j
% definition of process variables: 
dydt = S'*rho;




