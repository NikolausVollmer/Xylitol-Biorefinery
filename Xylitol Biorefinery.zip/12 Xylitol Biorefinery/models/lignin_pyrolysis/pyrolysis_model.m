function [m_pyrolysis, y_pyrolysis, mf, hf, design] = pyrolysis_model(m_residue,c_in,stats)
%PYROLYSIS MODEL FOR LIGNOCELLULOSIC BIOMASS PYROLYSIS 
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 04.03.2021
% calls to:
%  - pyrolysis_kinetics
%  - pyrolysis_parameters
%  - pyrolysis_mw

%% Molar masses
% MW_Glu = 180.156; % g/mol glucose
% MW_Cel = 162.1413; % g/mol cellulose monomer
% 
% MW_Xyl = 150.13; % g/mol xylose
% MW_Xyn = 132.1153; % g/mol xylan monomer
% 
% MW_Fur = 96.0846; % g/mol furfural
% MW_Hmf = 126.11; % g/mol 5-hydroxymethylfurfural
% 
% MW_LigC = 258.2663; % g/mol LigC
% MW_LigO = 422.3765; % g/mol LigO
% MW_LigH = 436.4459; % g/mol LigH

MW = pyrolysis_mw();

%% Input masses
x0 = zeros(51,1);
x0(1) = c_in(3) * 10 * m_residue / MW(1); % Cellulose
x0(52) = c_in(4) * 10 * m_residue / MW(52); % Glucose

x0(4) = (c_in(1) + c_in(5)) * 10 * m_residue / MW(4); % Xylan + Arabinan
x0(53) = (c_in(2) + c_in(6)) * 10 * m_residue / MW(53); % Xylose + Arabinose

x0(27) = c_in(11) * 10 * m_residue / MW(27); % Furfural
x0(28) = c_in(10) * 10 * m_residue / MW(28); % 5-HMF

% LigC, LigO, LigH for wheat straw according to Ranzi et al., 2017
x0(8) = 0.0015 * c_in(13) * 10 * m_residue / MW(8); % LigC
x0(9) = 0.9985 * c_in(13) * 10 * m_residue / MW(9); % LigO
x0(10) = 0 * 10 * m_residue / MW(10); % LigH


%% Parameters
[A,E] = pyrolysis_parameters();
pars = [A,E];


%% State variables
% 1. Temperature T
% 2. Reaction time t

time = stats(2); % [s]
stats = stats([1,2]);

x0(54) = 273.15 + 40; % Initial temperature in K

%% Time
% Time of residence
tspan = linspace(0,time,100);

%% Reaction
options = odeset('RelTol',1e-7,'AbsTol',1e-8);
[~,y] = ode45(@pyrolysis_kinetics,tspan,x0,options,pars,stats);


%% Output masses
% c_out based on 100g biomass dry
y_res = y(end,:);

% absolute mass of components
m_res= y_res([1:53]) .* MW / 1000;

m_pyrolysis = sum(m_res);
y_pyrolysis = m_res ./ m_pyrolysis;

Y_tar_aqueous = sum(m_res([14:24]))/sum(m_res);
Y_tar_nonaq = sum(m_res([25:33]))/sum(m_res);
Y_gas = sum(m_res([34:40]))/sum(m_res);
Y_char = sum(m_res([41:51]))/sum(m_res);

yields = [Y_tar_aqueous, Y_tar_nonaq, Y_gas, Y_char];

% Energy
H_R = pyrolysis_energy_balance(m_residue, stats(1));

% Sizing
V_Reactor = sizing_pyrolysis(m_residue, time);

% function output
mf = 0;
hf = H_R;


FCI = costing_pyrolysis(m_residue);

design = [V_Reactor, FCI];

end

%% ENERGY Balance
function H_R = pyrolysis_energy_balance(m_residue, T)
Cp = 2.185;   % heat capacity of water in kJ/kg/K
T0 = 298.15;    % initial temperature of 25 degC

H_R = m_residue * Cp * (T + 273.15 - T0); % Heating enthalpy in kJ

end

%% Sizing
function V_Reactor = sizing_pyrolysis(m_residue, time)

m_residue = m_residue / 1000; % biomass in t

% Volumetric capacity per hour
m_daily = m_residue / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant operates 24 h/d [t/h]
m_second = m_hourly / 3600; 

m_residence = m_second * time; % given mass flow per second times residence time (according to lecture slides 28350)
rho_gas = 0.875; % t/m3 - Pro/II

% Number and volume of reactors to satisfy capacity
V_Reactor = m_residence/rho_gas; % assuming a reactor with constant throughput (extruder-like, Prunescu et al. (2014)), with given residence time

end

%% Costing
function FCI = costing_pyrolysis(m_residue)

m_daily = m_residue/300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 58333; % kg/h

% Fixed capital investment for unit
FCI00 = 600000; % $(2010)
n = 21; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end

