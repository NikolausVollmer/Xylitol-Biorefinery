function [m_liquid, c_out_l, m_vapor, c_out_v, stats_out, mf, hf, design] = evaporation_model_xylitol(m, c_in, stats, Aspen)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Input
% Broth mass
m_broth = m;        % Broth mass in kg
rho_broth = 1.05;   % Broth density in t/m3

% Mass fractions
x_Xyl = c_in(2)/100;    % Fraction of xylose in broth - [wt% broth]
x_Xyo = c_in(18)/100;   % Concentration of xylitol in broth  - [wt% broth]
x_Glu = c_in(4)/100;    % Concentration of glucose in broth  - [wt% broth]
x_Ara = c_in(6)/100;    % Concentration of arabinose in broth  - [wt% broth]
x_Fac = c_in(8)/100;    % Concentration of formic acid in broth - [wt% broth]
x_Aac = c_in(9)/100;    % Concentration of acetic acid in broth - [wt% broth]
x_HMF = c_in(10)/100;   % Concentration of 5-HMF in broth - [wt% broth]
x_Fur = c_in(11)/100;   % Concentration of Furfural in broth - [wt% broth]
x_H2O = c_in(17)/100;   % Concentration of water in broth - [wt% broth]
x_Suf = c_in(14)/100;   % Concentration of sulfuric acid in broth - [wt% broth]
x_Shy = c_in(15)/100;   % Concentration of sodium hydroxide in broth - [wt% broth]

% Stats
y_vap = stats(1);   % fraction of the broth to be evaporated - [wt% of the broth]
T_in = stats(2); % temperature of ingoing broth
T_out = stats(3); % temperature of outgoing concentrated broth

%% ASPEN PLUS simulation
% Feed mass
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\TOTFLOW\MIXED').Value = m_broth; % Broth

% Mass Fractions
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\D-XYL-01').Value = x_Xyl; % Xylose fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\XYLIT-01').Value = x_Xyo; % Xylitol fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\DEXTR-01').Value = x_Glu; % Glucose fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\ARABI-01').Value = x_Ara; % Arabinose fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\FORMI-01').Value = x_Fac; % Formic acid fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\ACETI-01').Value = x_Aac; % Acetic acid fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\5-HYD-01').Value = x_HMF; % 5-HMF fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\FURFU-01').Value = x_Fur; % Furfural fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\WATER').Value = x_H2O; % Water fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\SULFU-01').Value = x_Suf; % Sulfuric acid fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\SODIU-01').Value = x_Shy; % Sodium hydroxide fraction

% Stats
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\TEMP\MIXED').Value = T_in + 273.15; % Input temperature of stream
Aspen.Tree.FindNode('\Data\Blocks\EVAP\Input\VFRAC').Value = y_vap; % Vapor fraction
Aspen.Tree.FindNode('\Data\Blocks\HEX-L\Input\TEMP').Value = T_out + 273.15; % Required output temperature

% Aspen.Reinit; % Reinitialise simulation
Aspen.Engine.Run2(1);
% 
while Aspen.Engine.IsRunning == 1 % 1 --> If Aspen is running; 0 ---> If Aspen stop.
    pause(3.0);
end

%% ASPEN PLUS output
% Liquid phase
m_liquid = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFLMX\MIXED').Value; % * 3600; % Mass flow liquid out
T_liquid = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\TEMP_OUT\MIXED').Value -273.15;    % degC;

x_Xyl_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\D-XYL-01').Value; % Xylose fraction in liquid fraction
x_Xyo_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\XYLIT-01').Value; % Xylitol fraction in liquid fraction
x_Glu_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\DEXTR-01').Value; % Glucose fraction in liquid fraction
x_Ara_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\ARABI-01').Value; % Arabinose fraction in liquid fraction
x_Fac_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\FORMI-01').Value; % Acetic acid fraction in liquid fraction
x_Aac_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\ACETI-01').Value; % Formic acid fraction in liquid fraction
x_HMF_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\5-HYD-01').Value; % 5-HMF fraction in liquid fraction
x_Fur_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\FURFU-01').Value; % Furfural fraction in liquid fraction
x_H2O_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\WATER').Value; % Water fraction in liquid fraction
x_Suf_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\SULFU-01').Value; % Sulfuric acid fraction
x_Shy_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\SODIU-01').Value; % Sodium hydroxide fraction

% Vapor phase
m_vapor = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFLMX\MIXED').Value; % * 3600; % Mass flow vapor out
T_vapor = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\TEMP_OUT\MIXED').Value; % - 273.15;    % degC;

y_Xyl_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\D-XYL-01').Value; % Xylose fraction in vapor fraction
y_Xyo_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\XYLIT-01').Value; % Xylitol fraction in vapor fraction
y_Glu_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\DEXTR-01').Value; % Glucose fraction in vapor fraction
y_Ara_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\ARABI-01').Value; % Arabinose fraction in vapor fraction
y_Fac_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\FORMI-01').Value; % Acetic acid fraction in vapor fraction
y_Aac_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\ACETI-01').Value; % Formic acid fraction in vapor fraction
y_HMF_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\5-HYD-01').Value; % 5-HMF fraction in vapor fraction
y_Fur_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\FURFU-01').Value; % Furfural fraction in vapor fraction
y_H2O_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\WATER').Value; % Water fraction in vapor fraction
y_Suf_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\SULFU-01').Value; % Sulfuric acid fraction
y_Shy_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\SODIU-01').Value; % Sodium hydroxide fraction

% Energies
H_Lcool = Aspen.Tree.FindNode("\Data\Blocks\HEX-L\Output\QNET").Value * 0.001 * 3600;    % kJ
H_Vcool = Aspen.Tree.FindNode("\Data\Blocks\HEX-V\Output\QNET").Value * 0.001 * 3600;    % kJ
H_evap = Aspen.Tree.FindNode("\Data\Blocks\EVAP\Output\QNET").Value * 0.001 * 3600;       % kJ

%% Output concentrations
c_Xyl_l = x_Xyl_out * 100;
c_Xyo_l = x_Xyo_out * 100;
c_Glu_l = x_Glu_out * 100;
c_Ara_l = x_Ara_out * 100;
c_Fac_l = x_Fac_out * 100;
c_Aac_l = x_Aac_out * 100;
c_HMF_l = x_HMF_out * 100;
c_Fur_l = x_Fur_out * 100;
c_H2O_l = x_H2O_out * 100;
c_Suf_l = x_Suf_out * 100;
c_Shy_l = x_Shy_out * 100;
c_out_l = [0, c_Xyl_l, 0, c_Glu_l, 0, c_Ara_l, 0, c_Fac_l, c_Aac_l, c_HMF_l, c_Fur_l, 0, 0, c_Suf_l, c_Shy_l, 0, c_H2O_l, c_Xyo_l, 0, 0];

c_Xyl_v = y_Xyl_out * 100;
c_Xyo_v = y_Xyo_out * 100;
c_Glu_v = y_Glu_out * 100;
c_Ara_v = y_Ara_out * 100;
c_Fac_v = y_Fac_out * 100;
c_Aac_v = y_Aac_out * 100;
c_HMF_v = y_HMF_out * 100;
c_Fur_v = y_Fur_out * 100;
c_H2O_v = y_H2O_out * 100;
c_Suf_v = y_Suf_out * 100;
c_Shy_v = y_Shy_out * 100;
c_out_v = [0, c_Xyl_v, 0, c_Glu_v, 0, c_Ara_v, 0, c_Fac_v, c_Aac_v, c_HMF_v, c_Fur_v, 0, 0, c_Suf_v, c_Shy_v, 0, c_H2O_v, c_Xyo_v, 0, 0];

stats_out = [T_liquid, T_vapor];

V_evaporator = Sizing(m_broth, rho_broth);

FCI = costing_evaporation_xylitol(m_broth);

% output
mf = [];
hf = [H_evap, H_Lcool, H_Vcool];

design = [V_evaporator, FCI];    

end

%% Sizing
function V_evaporator = Sizing(m_broth, rho_broth)
time = 1; % [h]

m_broth = m_broth / 1000; % broth mass [t]

% Volumetric capacity per hour
m_daily = m_broth / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly = m_hourly / rho_broth; % based on experimental values, where 300g correspond to 600mL reactor volume [m3/h]

V_evaporator = V_total_hourly * time;

end

%% Costing
function FCI = costing_evaporation_xylitol(m_broth)

m_daily = m_broth/300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 15445; % kg/h

% Fixed capital investment for unit
FCI00 = 491000; % $(2002)
n = 18; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end
