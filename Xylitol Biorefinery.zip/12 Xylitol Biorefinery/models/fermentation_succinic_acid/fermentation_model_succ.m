function [m_broth, c_out, mf, hf, design] = fermentation_model_succ(m,c_in,stats)
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here

time = stats(1);
c_inoc = stats(2);
Vfrac = stats(3);
tfstart = stats(4);
tfend = stats(5);

c_inoc = 3/Vfrac;

%% Parameters
par = fermentation_succ_parameters();

rho_substrate = 1.02;  % substrate density in kg/L, assumed constant over time
rho_broth = 1.05;      % broth density in kg/L, assumed constant over time

Cp_CO2 = 0.915;            % kJ/kg/K
Cp_H2O = 4.19;         % kJ/kg/K

T_ext = 25;            % degC
T_ferm = 30;

%% Time
% Time of residence
tlength = ceil(time/24)*1000;
tspan = linspace(0,time,tlength);

%% State variables
% other state variables are taken out of the vector

V_0 = Vfrac * m / rho_substrate; % in L
V_total = m / rho_substrate; % in L

F_in = feed_rate(V_0, V_total, time, tfstart, tfend);

%% Initial conditions
m_in = m;
V = m_in / rho_broth;

c_Glu0 = c_in(4) * 10 * rho_substrate;
c_X0 = c_inoc;
c_Sac0 = 0;
c_Fac0 = c_in(8) * 10 * rho_substrate;
c_Aac0 = c_in(9) * 10 * rho_substrate;

x0(1) = c_Glu0; % Initial concentration of Glucose in g/L hydrolyzate
x0(2) = c_X0;   % Initial concentration of cell biomass in g/L hydrolyzate
x0(3) = c_Sac0; % Initial concentration of succinic acid in g/L hydrolyzate
x0(4) = c_Fac0; % Initial concentration of formic acid in g/L hydrolyzate
x0(5) = c_Aac0; % initial concentration of acetic acid in g/L hydrolyzate
x0(6) = V_0;    % Initial volume in L

% Stats for fed-batch fermentation
stats(1) = c_in(4) * 10 * rho_substrate; % Initial Concentration of Glucose
stats(2) = F_in;
stats(3) = time;
stats(4) = tfstart;
stats(5) = tfend;


%% Black-Box model
% Black-box kinetics for substrate, biomass and product
options = odeset('RelTol',1e-7,'AbsTol',1e-8,'NonNegative',[1:6]);
[~,y] = ode45(@fermentation_succ_kinetics,tspan,x0,options,par,stats);

% figure
% hold on
% plot(tspan,y(:,1),'r')
% plot(tspan,y(:,2),'b')
% plot(tspan,y(:,3),'k')
% plot(tspan,y(:,4),'y')
% plot(tspan,y(:,5),'g')

% Rates from BBM and calculated rates via stoichiometry
[q_Glu, mu, q_Sac, q_Fac, q_Aac, q_CO2, q_NH4, q_H2O, q_Proton, q_Ethanol, q_Heat, regime] = Process_Reaction(y,par);
    
    
%% Flows/Masses for gas phase, nitrogen source and titrant
% Flow of CO2 out
F_CO2_out = 0.1 .* abs(q_CO2)'.*y(:,2) * V;
M_CO2_out = mean(F_CO2_out) * time * 1e-3;

% Flow of CO2 in
F_CO2_in = F_CO2_out + abs(q_CO2)'.*y(:,2) * V;
M_CO2_in = mean(F_CO2_in) * time * 1e-3;

% Flow of evaporated water
F_evap = F_CO2_out .* 0.0584 * 0.1; % assuming being the same as water! y_H20_out = 0.0584 due to saturation pressure at 30degC, phi = 0.2, assuming that air is 10% saturated when exiting the fermentor
M_evap = mean(F_evap) * time * 1e-3;

% Transfered CO2
F_CO2 = abs(q_CO2)'.*y(:,2) * V;
M_CO2 = mean(F_CO2) * time * 1e-3;

% Flow of pure nitrogen source
F_nitro = abs(q_NH4)'.*y(:,2) * V;
M_nitro = mean(F_nitro) * time * 1e-3;

% Flow of pure titrant
F_titr = abs(q_Proton)'.*y(:,2) * V;
M_titr = mean(F_titr) * time * 1e-3;

% Created mass of ethanol
F_EtOH = abs(q_Ethanol)'.*y(:,2) * V;
M_EtOH = mean(F_EtOH) * time * 1e-3;

% Created mass of water
F_H2O = abs(q_H2O)' .* y(:,2) * V;
M_H2O = mean(F_EtOH) * time * 1e-3;

% Output masses
c_broth = y(end,:);
c_broth= c_broth/ (10 * rho_broth);

m_broth = m_in + M_CO2_in + M_nitro + M_titr - M_CO2_out - M_evap;
m_out = m_broth;

delta = (m_out - m_in)/m_in * 100;

% Output concentrations
mm_broth = y(end,[1,3,4,5]) * V * 1e-3; % [kg]
M_biomass = y(end,2) * V * 1e-3;

mm_out = c_in /100 * m_in; % kg

mm_out(4) = mm_broth(1); % kg
mm_out(19) = mm_broth(2); % kg
mm_out(8) = mm_broth(3); % kg
mm_out(9) = mm_broth(4); % kg
mm_out(20) = M_EtOH; % kg

mm_out(17) = 0; % reset to zero
mm_out(17) = m_broth - sum(mm_out); % remaining mass is water

c_out = mm_out ./ m_broth .* 100;

%% Heat balance
F_HR = abs(q_Heat)'.*y(:,2) * V;
HR = mean(F_HR) * time * 1e-3;

H_in = M_CO2_in * Cp_CO2 * T_ext;
H_out = M_CO2_out * Cp_CO2 * T_ferm + M_evap * Cp_H2O * T_ferm;

H_ext = H_out - H_in + HR;

% Sizing
V_reactor = Sizing(m_broth, rho_broth, time);

% Costing
FCI = costing_fermentation_succ(m_broth);

% Function output
mf(1) = M_CO2_in;
mf(2) = M_nitro;
mf(3) = M_titr;
mf(4) = M_CO2_out;
mf(5) = M_biomass;

hf = H_ext;

design = [V_reactor, FCI];


end

%% Feed rate
function F_in = feed_rate(V_0, V_total, time, tfstart, tfend)

if tfend > tfstart
    F_in = (V_total - V_0) / ((tfend - tfstart)* time); % in L/h
else
    F_in = 0;
end

end

%% Process Reaction
function [q_Glu, mu, q_Sac, q_Fac, q_Aac, q_CO2, q_NH4, q_H2O, q_Proton, q_Ethanol, q_Heat, regime] = Process_Reaction(y,par);
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

%% Standard Enthalpies of Fusion
HR_Glu = -1273.48; % kJ/mol - Pro/II
HR_Sac = -822.9; % kJ/mol - Pro/II
HR_Fac = -378.6; % kJ/mol - Pro/II
HR_Aac = -432.8; % kJ/mol - Pro/II
HR_NH4 = -132.8;   % kJ/mol - Pro/II (for ammonium ion)
HR_O2 = 0;         % kJ/mol - Pro/II
HR_X = -119.83;    % kJ/mol - paper wang et al 1976
HR_CO2 = -393.51;  % kJ/mol - Pro/II
HR_H2O = -241.82;  % kJ/mol - Pro/II
HR_Proton = 0;     % kJ/mol

MM_Glu = 0.180;    % kg/mol
MM_Sac = 0.1181;    % kg/mol
MM_Fac = 0.046;    % kg/mol
MM_Aac = 0.06;    % kg/mol
MM_NH4 = 0.018;    % kg/mol
MM_O2 = 0.032;     % kg/mol
MM_X = 0.0246;     % kg/mol
MM_CO2 = 0.044;    % kg/mol
MM_H2O = 0.018;    % kg/mol
MM_Proton = 0.001; % kg/mol
MM_Ethanol = 0.04607; % kg/mol

%% BBM Rates & Herbert-Pirt relation parameters

a_Glu = par(5);
b1_Glu_Sac = par(6);
b1_Glu_Fac = par(7);
b1_Glu_Aac = par(8);
ms_Glu = par(9);

b2_Glu_Sac = par(13);
b2_Glu_Fac = par(14);
b2_Glu_Aac = par(15);

C_I_Ac = par(16);


[q_Glu, mu, q_Sac, q_Fac, q_Aac] = rates(y,par);

%%%
q_Glu = q_Glu .* MM_X ./ MM_Glu;
mu = mu;
q_Sac = q_Sac .* MM_X ./ MM_Sac;
q_Fac = q_Fac .* MM_X ./ MM_Fac;
q_Aac = q_Aac .* MM_X ./ MM_Aac;

a_Glu = a_Glu * MM_X / MM_Glu;
ms_Glu = ms_Glu;
b1_Glu_Sac = b1_Glu_Sac * MM_Sac / MM_Glu;
b1_Glu_Fac = b1_Glu_Fac * MM_Fac / MM_Glu;
b1_Glu_Aac = b1_Glu_Aac * MM_Aac / MM_Glu;
b2_Glu_Sac = b2_Glu_Sac * MM_Sac / MM_Glu;
b2_Glu_Fac = b2_Glu_Fac * MM_Fac / MM_Glu;
b2_Glu_Aac = b2_Glu_Aac * MM_Aac / MM_Glu;

%%%

%% Process reactions
% Process Reaction - Glucose, growth
A1 = [[1 0 0 0];...
      [0 4 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];
  
b1 = [[6*a_Glu - 1];...
      [12*a_Glu - 1.8];...
      [0.2];...
      [0]];
  
vec1 = A1\b1;


% Process Reaction - Glucose, Succinic Acid production, phase I
A2 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b2 = [[6*b1_Glu_Sac - 4];...
      [12*b1_Glu_Sac - 6];...
      [0];...
      [0]];

  
vec2 = A2\b2;

% Process Reaction - Glucose, Succinic Acid production, phase II
A3 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b3 = [[6*b2_Glu_Sac - 4];...
      [12*b2_Glu_Sac - 6];...
      [0];...
      [0]];

  
vec3 = A3\b3;

% Process Reaction - Glucose, Formic Acid production, phase I
A4 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b4 = [[6*b1_Glu_Fac - 1];...
      [12*b1_Glu_Fac - 2];...
      [0];...
      [0]];

  
vec4 = A4\b4;

% Process Reaction - Glucose, Formic Acid production, phase II
A5 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b5 = [[6*b2_Glu_Fac - 1];...
      [12*b2_Glu_Fac - 2];...
      [0];...
      [0]];

  
vec5 = A5\b5;

% Process Reaction - Glucose, Acetic Acid production, phase I
A6 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b6 = [[6*b1_Glu_Aac - 2];...
      [12*b1_Glu_Aac - 4];...
      [0];...
      [0]];

  
vec6 = A6\b6;

% Process Reaction - Glucose, Formic Acid production, phase II
A7 = [[1 0 0 0];...
      [0 0 2 0];...
      [0 1 0 0];...
      [0 4 0 -1]];

  
b7 = [[6*b2_Glu_Aac - 2];...
      [12*b2_Glu_Aac - 4];...
      [0];...
      [0]];

  
vec7 = A7\b7;

% Process Reaction - Glucose, maintenance
A8 = [[1 2];...
      [0 6]];

  
b8 = [[6];...
      [12]];

  
vec8 = A8\b8;


%% Rate parameters
% Carbon dioxide
ratio_CO2 = [vec1(1), vec2(1), vec3(1), vec4(1), vec5(1), vec6(1), vec7(1), vec8(1)];

% Ammonium
ratio_NH4 = [vec1(2), vec2(2), vec3(2), vec4(2), vec5(2), vec6(2), vec7(2)];

% Water
ratio_H2O = [vec1(3), vec2(3), vec3(3), vec4(3), vec5(3), vec6(3), vec7(3)];

% Proton
ratio_Proton = [vec1(4), vec2(4), vec3(4), vec4(4), vec5(4), vec6(4), vec7(4)];

% Ethanol
ratio_Ethanol = [vec8(2)];


%% Herbert-Pirt Rates for other components
C_Ac = y(:,3) + y(:,4) + y(:,5);
freg = find(C_Ac > C_I_Ac, 1);
if isempty(freg)
    regime = length(y(:,1));
else
    regime = freg;
end
total = length(y(:,1));

% Black-box kinetics qs, mu_ qp
q_Glu = -q_Glu;
mu = mu;
q_Sac = q_Sac;
q_Fac = q_Fac;
q_Aac = q_Aac;

% Carbon Dioxide
if regime > 1
    q_CO2a = ratio_CO2(1) .* mu(1:regime) + ratio_CO2(2) .* q_Sac(1:regime) + ratio_CO2(4) .* q_Fac(1:regime) + ratio_CO2(6) .* q_Aac(1:regime) + ratio_CO2(8) .* ms_Glu;
    q_CO2b = ratio_CO2(3) .* q_Sac(regime+1:total) + ratio_CO2(5) .* q_Fac(regime+1:total) + ratio_CO2(7) .* q_Aac(regime+1:total) + ratio_CO2(8) .* ms_Glu;
    q_CO2 = horzcat(q_CO2a, q_CO2b);
else
    q_CO2 = ratio_CO2(3) .* q_Sac(1:total) + ratio_CO2(5) .* q_Fac(1:total) + ratio_CO2(7) .* q_Aac(1:total);
end

% Ammonium
if regime > 1
    q_NH4a = ratio_NH4(1) .* mu(1:regime) + ratio_NH4(2) .* q_Sac(1:regime) + ratio_NH4(4) .* q_Fac(1:regime) + ratio_NH4(6) .* q_Aac(1:regime);
    q_NH4b = ratio_NH4(3) .* q_Sac(regime+1:total) + ratio_NH4(5) .* q_Fac(regime+1:total) + ratio_NH4(7) .* q_Aac(regime+1:total);
    q_NH4 = horzcat(q_NH4a, q_NH4b);
else
    q_NH4 = ratio_NH4(3) .* q_Sac(1:total) + ratio_NH4(5) .* q_Fac(1:total) + ratio_NH4(7) .* q_Aac(1:total);
end

% Water
if regime > 1
    q_H2Oa = ratio_H2O(1) .* mu(1:regime) + ratio_H2O(2) .* q_Sac(1:regime) + ratio_H2O(4) .* q_Fac(1:regime) + ratio_H2O(6) .* q_Aac(1:regime);
    q_H2Ob = ratio_H2O(3) .* q_Sac(regime+1:total) + ratio_H2O(5) .* q_Fac(regime+1:total) + ratio_H2O(7) .* q_Aac(regime+1:total);
    q_H2O = horzcat(q_H2Oa, q_H2Ob);
else
    q_H2O = ratio_H2O(3) .* q_Sac(1:total) + ratio_H2O(5) .* q_Fac(1:total) + ratio_H2O(7) .* q_Aac(1:total);
end

% Proton
if regime > 1
    q_Protona = ratio_Proton(1) .* mu(1:regime) + ratio_Proton(2) .* q_Sac(1:regime) + ratio_Proton(4) .* q_Fac(1:regime) + ratio_Proton(6) .* q_Aac(1:regime);
    q_Protonb = ratio_Proton(3) .* q_Sac(regime+1:total) + ratio_Proton(5) .* q_Fac(regime+1:total) + ratio_Proton(7) .* q_Aac(regime+1:total);
    q_Proton = horzcat(q_Protona, q_Protonb);
else
    q_Proton = ratio_Proton(3) .* q_Sac(1:total) + ratio_Proton(5) .* q_Fac(1:total) + ratio_Proton(7) .* q_Aac(1:total);
end

% Ethanol
q_Ethanol = ms_Glu * ratio_Ethanol(1);

%%%
q_CO2 = q_CO2 * MM_CO2;
q_NH4 = q_NH4 * MM_NH4;
q_H2O = q_H2O * MM_H2O;
q_Proton = q_Proton * MM_Proton;
q_Ethanol = q_Ethanol * MM_Ethanol;
%%%
    

% Heat production rate
q_Heat = zeros(1,total);
q_Heat(:) = mu(:).*HR_X/MM_X + q_Glu(:).*HR_Glu/MM_Glu + q_Sac(:).*HR_Sac/MM_Sac + q_Fac(:).*HR_Fac/MM_Fac + q_Aac(:).*HR_Aac/MM_Aac + q_CO2(:).*HR_CO2/MM_CO2 + q_NH4(:).*HR_NH4/MM_NH4 + q_H2O(:).*HR_H2O/MM_H2O;
  
end

%% Herbert-Pirt
function [a_Glu, ms_Glu, a_Xyl, b_Xyl, ms_Xyl] = Herbert_Pirt(rate_vector,y)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%% Check substrate regimes
reg1_Glu = y(1,:,1);
reg2_Glu = y(2,:,1);
reg3_Glu = y(3,:,1);

reg1_Glu = length(reg1_Glu(reg1_Glu > 0.1));
reg2_Glu = length(reg2_Glu(reg2_Glu > 0.1));
reg3_Glu = length(reg3_Glu(reg3_Glu > 0.1));

reg_Glu = [reg1_Glu, reg2_Glu, reg3_Glu];
clear reg1_Glu reg2_Glu reg3_Glu

reg1_Xyl = y(1,:,2);
reg2_Xyl= y(2,:,2);
reg3_Xyl = y(3,:,2);

reg1_Xyl = length(reg1_Xyl(reg1_Xyl > 0.1));
reg2_Xyl = length(reg2_Xyl(reg2_Xyl > 0.1));
reg3_Xyl = length(reg3_Xyl(reg3_Xyl > 0.1));

reg_Xyl= [reg1_Xyl, reg2_Xyl, reg3_Xyl];
clear reg1_Xyl reg2_Xyl reg3_Xyl

%% Split rate vectors
q_Glu_rates = squeeze(rate_vector(1,:,:));
q_Xyl_rates = squeeze(rate_vector(2,:,:));
mu_rates = squeeze(rate_vector(3,:,:));
q_Xyo_rates = squeeze(rate_vector(4,:,:));

clear rate_vector

q_Glu1 = q_Glu_rates(1,1:reg_Glu(1));
q_Glu2 = q_Glu_rates(2,1:reg_Glu(2));
q_Glu3 = q_Glu_rates(3,1:reg_Glu(3));

mu_Glu1 = mu_rates(1,1:reg_Glu(1));
mu_Glu2 = mu_rates(2,1:reg_Glu(2));
mu_Glu3 = mu_rates(3,1:reg_Glu(3));

q_Xyl1 = q_Xyl_rates(1,reg_Glu(1)+1:reg_Xyl(1));
q_Xyl2 = q_Xyl_rates(2,reg_Glu(2)+1:reg_Xyl(2));
q_Xyl3 = q_Xyl_rates(3,reg_Glu(3)+1:reg_Xyl(3));

mu_Xyl1 = mu_rates(1,reg_Glu(1)+1:reg_Xyl(1));
mu_Xyl2 = mu_rates(2,reg_Glu(2)+1:reg_Xyl(2));
mu_Xyl3 = mu_rates(3,reg_Glu(3)+1:reg_Xyl(3));

q_Xyo1 = q_Xyo_rates(1,reg_Glu(1)+1:reg_Xyl(1));
q_Xyo2 = q_Xyo_rates(2,reg_Glu(2)+1:reg_Xyl(2));
q_Xyo3 = q_Xyo_rates(3,reg_Glu(3)+1:reg_Xyl(3));

%% rates

q_Glu1 = mean(q_Glu1);
q_Glu2 = mean(q_Glu2);
q_Glu3 = mean(q_Glu3);

mu_Glu1 = mean(mu_Glu1);
mu_Glu2 = mean(mu_Glu2);
mu_Glu3 = mean(mu_Glu3);

q_Xyl1 = mean(q_Xyl1);
q_Xyl2 = mean(q_Xyl2);
q_Xyl3 = mean(q_Xyl3);

mu_Xyl1 = mean(mu_Xyl1);
mu_Xyl2 = mean(mu_Xyl2);
mu_Xyl3 = mean(mu_Xyl3);

q_Xyo1 = mean(q_Xyo1);
q_Xyo2 = mean(q_Xyo2);
q_Xyo3 = mean(q_Xyo3);

%% factors a,b for Glucose

% a_Glu = (q_Glu2 - q_Glu3) / (mu_Glu2 - mu_Glu3);
% ms_Glu = q_Glu2 - a_Glu * mu_Glu2;
A = [[mu_Glu2 1];[mu_Glu3 1]];
b = [[q_Glu2];[q_Glu3]];
vec = A\b;
a_Glu = vec(1);
ms_Glu = vec(2);


%% factors a,b for Xylose

A = [[mu_Xyl1 q_Xyo1 1];[mu_Xyl2 q_Xyo2 1];[mu_Xyl3 q_Xyo3 1]];
b = [[q_Xyl1];[q_Xyl2];[q_Xyl3]];
vec = A\b;
a_Xyl = vec(1);
b_Xyl = vec(2);
ms_Xyl = vec(3);
    

rates = [a_Glu, ms_Glu, a_Xyl, b_Xyl, ms_Xyl];

end 

%% Rate 
function [q_Glu, mu, q_Sac, q_Fac, q_Aac] = rates(y,par)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Concentrations
C_Glu = y(:,1);
C_Sac = y(:,3);
C_Fac = y(:,4);
C_Aac = y(:,5);

n = length(C_Glu);

q_Glu = zeros(1,n);
mu = zeros(1,n);
q_Sac = zeros(1,n);
q_Fac = zeros(1,n);
q_Aac = zeros(1,n);

% Parameters
q_Glu_max = par(1);
K_Glu = par(2);
K_I_Glu = par(3);
K_I_Ac = par(4);


a_Glu = par(5);
b1_Glu_Sac = par(6);
b1_Glu_Fac = par(7);
b1_Glu_Aac = par(8);
ms_Glu = par(9);

beta_Sac = par(10);
beta_Fac = par(11);
beta_Aac = par(12);

b2_Glu_Sac = par(13);
b2_Glu_Fac = par(14);
b2_Glu_Aac = par(15);

C_I_Ac = par(16);

% Calculation q_Glu
for i = 1:n
    q_Glu(i) = q_Glu_max * (C_Glu(i)/(K_Glu + C_Glu(i))) * (1/(1 + C_Glu(i)/K_I_Glu)) * (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-K_I_Ac)));
end

% Calculation mu
for i = 1:n
    mu(i) = (q_Glu(i) - (162/114 * b1_Glu_Sac * beta_Sac) - (b1_Glu_Fac * beta_Fac) - (b1_Glu_Aac * beta_Aac) - ms_Glu) / a_Glu * (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac)));
end

% Calculation q_Sac
for i = 1:n
    q_Sac(i) = 162/114 * beta_Sac * (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))) + ...
        b2_Glu_Sac * q_Glu(i) * (1 - (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))));
end

% Calculation q_Fac
for i = 1:n
    q_Fac(i) =  beta_Fac * (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))) + ...
        b2_Glu_Fac * q_Glu(i) * (1 - (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))));
end

% Calculation q_Aac
for i = 1:n
    q_Aac(i) = beta_Aac * (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))) + ...
        b2_Glu_Aac * q_Glu(i) * (1 - (1/(1+exp((C_Sac(i) + C_Fac(i) + C_Aac(i))-C_I_Ac))));
end


end

%% FluxToMass
function m = FluxToMass(f,reg,tlength,time)
% Calculating absolute masses from fluxes in different substrate regimes


f_Glu = f([1:reg(1)]);
f_Xyl = f([reg(1)+1:reg(2)]);
f_Xyo = f([reg(2)+1:reg(3)]);

m_Glu = mean(f_Glu) * reg(1)/tlength * time;
m_Xyl = mean(f_Xyl) * (reg(2) - reg(1))/tlength * time;

if reg(3) > reg(2)
    m_Xyo = mean(f_Xyo) * (reg(3) - reg(2))/tlength * time;
else
    m_Xyo = 0;
end

m = m_Glu + m_Xyl + m_Xyo;

end

%% Sizing
function V_reactor = Sizing(m_broth, rho_broth, time)

m_broth = m_broth / 1000; % Broth mass  [t]

% Volumetric capacity per hour
m_daily = m_broth / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly = m_hourly / rho_broth; % broth density [t/m3]

V_reactor = V_total_hourly * time;

end

%% Costing
function FCI = costing_fermentation_succ(m_broth)

m_daily = m_broth/300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 425878; % kg/h

% Fixed capital investment for unit
FCI00 = 3362334; % $(2010)
n = 10; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end




