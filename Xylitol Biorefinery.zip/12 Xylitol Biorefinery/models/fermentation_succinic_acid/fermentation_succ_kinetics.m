function dydt = fermentation_succ_kinetics(t,y,par,stats)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% Stats
C_Glu_0 = stats(1); % Initial Concentration of Glucose
F_in = stats(2);
time = stats(3);
tfstart = stats(4);
tfend = stats(5);

f_in = feed(F_in, t, tfstart, tfend, time);

%% Concentrations
C_Glu = y(1);
C_X = y(2);
C_Sac = y(3);
C_Fac = y(4);
C_Aac = y(5);
V = y(6);

%% Parameters
q_Glu_max = par(1);
K_Glu = par(2);
K_I_Glu = par(3);
K_I_Ac = par(4);


a_Glu = par(5);
b1_Glu_Sac = par(6);
b1_Glu_Fac = par(7);
b1_Glu_Aac = par(8);
ms_Glu = par(9);

beta_Sac = par(10);
beta_Fac = par(11);
beta_Aac = par(12);

b2_Glu_Sac = par(13);
b2_Glu_Fac = par(14);
b2_Glu_Aac = par(15);

C_I_Ac = par(16);

%% Rates
% substrate uptake rate
q_Glu = q_Glu_max * (C_Glu/(K_Glu + C_Glu)) * (1/(1 + C_Glu/K_I_Glu)) * (1/(1+exp((C_Sac + C_Fac + C_Aac)-K_I_Ac)));

% growth rate on glucose (Herbert-Pirt)
mu = (q_Glu - (162/114 * b1_Glu_Sac * beta_Sac) - (b1_Glu_Fac * beta_Fac) - (b1_Glu_Aac * beta_Aac) - ms_Glu) / a_Glu * (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac)));

% q_p(mu) relation / production rate succinic acid
q_Sac = 162/114 * beta_Sac * (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))) + ...
    b2_Glu_Sac * (q_Glu - ms_Glu) * (1 - (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))));

% q_p(mu) relation / production rate formic acid
q_Fac =  beta_Fac * (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))) + ...
    b2_Glu_Fac * (q_Glu - ms_Glu) * (1 - (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))));

% q_p(mu) relation / production rate acetic acid
q_Aac = beta_Aac * (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))) + ...
    b2_Glu_Aac * (q_Glu - ms_Glu) * (1 - (1/(1+exp((C_Sac + C_Fac + C_Aac)-C_I_Ac))));

%% rates

% 1 - Glucose (Glu)
% 2 - Biomass (X)
% 3 - Succinic Acid (Sac)
% 4 - Formic Acid (Fac)
% 5 - Acetic Acid (Aac)
% 6 - Volume

dydt(1,1) = f_in/V * (C_Glu_0 - C_Glu) - q_Glu * C_X;
dydt(2,1) = (mu - f_in/V) * C_X;
dydt(3,1) = q_Sac * C_X - f_in/V * C_Sac;
dydt(4,1) = q_Fac * C_X - f_in/V * C_Fac;
dydt(5,1) = q_Aac * C_X - f_in/V * C_Aac;
dydt(6,1) = f_in;

end

function f_in = feed(F_in, t, tfstart, tfend, time)

if t < tfstart*time
    f_in = 0;
    
elseif tfstart * time < t < tfend * time
    f_in = F_in;
    
elseif t > tfend * time
    f_in = 0;
    
end

end

