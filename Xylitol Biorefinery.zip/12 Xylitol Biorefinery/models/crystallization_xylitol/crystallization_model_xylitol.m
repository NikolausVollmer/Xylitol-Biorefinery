function [m_out, c_out, stats_out, mf, hf, design] = crystallization_model_xylitol(m_in, c_in, stats)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
% global T0 Tf Fin_a tfinal Cini F_j V_j rho_w rho_a Cp_w Cp_a X_a w_a rho_solv MW_w MW_a Vini rho_c DHc ka kv MW_c L_min L_max L0 Grow U Tc A Nuc xini

%% INPUT
% mass
m_liquid = m_in / 300 / 24 * stats(1); % scale from total mass per year to mass of batch

% Stats 
T0_L = stats(2);              % Initial temperature - [degC]
tf = stats(1)*3600;           % Batch time [s]
F_AS = stats(4);              % Flowrate of antisolvent - [kg/s]
F_C = stats(5);               % Coolant flowrate [kg/s]
T0_C = stats(3);              % Initial coolant temperature - [degC]
rho_liquid = stats(6);        % Density of the incoming broth - [kg/m3]

% Parameters for solvent (H2O) and antisolvent (Ethanol)
rho_L = 1000;                 % Density water - [kg/m3]
rho_AS = 789;                 % Density antisolvent (Ethanol) - [kg/m3]
Mw_L = 18.02;                 % Molecular weight water - [g/mol]
Mw_AS = 46.07;                % Molecular weight antisolvent - [g/mol]
Cp_L = 4184;                  % Constant liquid heat capacity water - [J/kg/degC]
Cp_AS = 2460;                 % Constant liquid heat capacity antisolvent - [J/kg/degC]
V0 = m_liquid/rho_L;          % Initial liquid volume - [m3]

X_AS = 0; 
w_AS = Mw_AS*X_AS / ((Mw_AS-Mw_L)*X_AS + Mw_L); % Weight fraction of antisolvent in solvent - [-]
rho_Sol = 1 / (w_AS/rho_AS + (1-w_AS)/rho_L);   % Density of solvent (H2O + EtOH) - [kg/m3]

c_H2O = c_in(17);            % Concentration of water in liquid - [g H2O/100g liquid]
m_H2O = m_liquid * c_H2O / 100;     % Mass of water in liquid - [kg]


par_solvent = [rho_L, rho_AS, Mw_L, Mw_AS, Cp_L, Cp_AS];

% Parameters for xylitol crystals
rho_Xyo = 1520;               % Density pf xylitol   [kg/m3]     % according to Wikipedia
DH_fus_Xyo = 37.7*10^3;       % Enthalpy of fusion/crystallization of xylitol [J/kmol], according to NIST  
ka = 5.1;                     % Surface shape factor                         
kv = 0.83;                    % Volumetric shape factor                            
Mw_Xyo = 152.146;             % Molecular weight xylitol [g/mol]
% L_min = 10e-6;                % Minimum crystal size [m]                 
% L_max = 1050e-6;              % Maximum crystal size [m]                
L0 = 5e-6;                    % Critical nuclei size [m]                 
% L_seed_max = 10e-6;           % Maximum crystal size in seed   [m]                 

% Parameters for seed mass
seed_mass = 0.025;              % seed mass of xylitol crystals [kg Xylitol/kg solvent]      
seed_mean = 400e-6;              % Mean seed size [m]
m0_Xyo = c_in(18) * m_liquid/100; % Initial mass of solute [kg Xylitol]
Cini = m0_Xyo/V0;               % Initial volumetric concentration of xylitol [kg Xylitol/m3]

par_Xyo = [rho_Xyo, DH_fus_Xyo, ka, kv, Mw_Xyo, L0];

% Initial seed parameters (ask Merve?)
mu0_ini = (seed_mass * rho_Sol/rho_Xyo) / ((seed_mean/2)^3 * pi * 4/3*kv);  % [#/m3] 
mu1_ini = mu0_ini * seed_mean;                                              % [m/m3]
mu2_ini = mu0_ini * (seed_mean/2)^2 * pi * 4 * ka;                          % [m2/m3]
mu3_ini = mu0_ini * (seed_mean/2)^3 * pi * 4/3 * kv;                        % [m3/m3]

% Parameters for cooling liquid and crystallizer design
Vf = V0 + F_AS/rho_AS * tf;                   % Final volume of liquid with crystals - [m3]
H = 0.5;                                      % Heigth of crystallizer [m]
D = 2 * sqrt(Vf/pi/H);                        % Diameter of crystallizer[m]
U = 1275;                                     % Heat transfer coefficient [W/m^2C]
V_j = pi * H/4 * (((D + 2*0.010)^2) - (D^2)); %V_j=pi*0.6/4*(((0.642+2*0.010)^2)-(0.642^2));   %[m^3]
A = pi * D * H;                               % A=pi*0.642*0.6;   %Heat transfer area [m^2]  A=D*H*h (D and H is working area of crystallizer)

par_design = [U, T0_C, A, F_C, V_j];

%% Stats for Kinetic model
stats = [m_H2O, F_AS, V0, m0_Xyo];

%% Kinetic Model - Method of Moments
options = odeset('RelTol',1e-7,'AbsTol',1e-8,'NonNegative',[1:8]);
xini = [mu0_ini mu1_ini mu2_ini mu3_ini m0_Xyo T0_L T0_C m_H2O];
[t x] = ode45(@crystallization_xylitol_mom, [0 tf], xini, options, par_solvent, par_Xyo, par_design, stats);
% 
% for i = 1:length(x)
%     C_Xyo_sol(i,1) = m0_Xyo - rho_Xyo * kv * (x(i,4) - x(1,4));
% end


%% Output masses
% mass of crystals
m_cryst_single = x(1,5) - x(end,5);
m_cryst = m_cryst_single * 300 * 24 / (tf/3600);

% output mass = input mass + antisolvent + m_cryst
m_slurry = m_liquid + F_AS*tf - m_cryst_single;
m_out = m_slurry * 300 * 24 / (tf/3600);

% mass of antisolvent
m_AS = F_AS*tf * 300 * 24 / (tf/3600);

% output concentrations
mm_out = c_in * m_in / 100;
mm_out(18) = mm_out(18) - m_cryst;

c_out = mm_out ./ sum(mm_out) .* 100;

%% Energy balance
FH_C = F_C * Cp_L * 0.001 * (x(:,7) - T0_C);
H_C = mean(FH_C) * tf;



%x(:,1)=mu0 x(:,2)=mu1 (total L of crystals), x(:,3)=mu2 (Total A of crystals, x(:,4)=mu3 (Total V of crystals)
%x(:,5)=mu4, x(:,6)=m (xylitol mass liquid phase g), x(:,7)=T (temperature
%in crystallizer), x(:,8)=Tc, x(:,9)=mass in tank

% m_end = x(end,6); % Final mass of xylitol in liquid phase
% 
% %Calculating yield and mass of xylitol crystals per solvent volume
% yield = (x(1,6)-x(end,6))/(x(1,6));       
% Mass_c = x(end,6);                      %kg xylitol
% MeanSize = x(end,2)/x(end,1);           %[m]
% 
% %Solubility regression parameters
% p00 = 1.635;
% p10 = -44.2;
% p20 = 257.4;
% p11 = -0.152;
% p01 = 8.032*10^(-4);
% p02 = -1.703*10^(-4);
p00 =       0.439; %  (-0.8005, 1.679)
p10 =     0.07287; %  (-0.005897, 0.1516)
p01 =      0.6919; %  (-14, 15.38)
p20 =   -0.002748; %  (-0.007239, 0.001743)
p11 =     -0.1995; %  (-0.5596, 0.1605)
p02 =      -9.889; %  (-73.44, 53.66)
p30 =    9.57e-05; %  (-1.73e-05, 0.0002087)
p21 =    0.005098; %  (-0.005521, 0.01572)
p12 =       0.352; %  (-0.4807, 1.185)
p03 =        27.9; %  (-99.3, 155.1)
p40 =  -8.875e-07; %  (-1.894e-06, 1.193e-07)
p31 =  -0.0001371; %  (-0.0003292, 5.491e-05)
p22 =  -0.0008635; %  (-0.012, 0.01027)
p13 =     -0.4968; %  (-1.427, 0.4337)
p04 =      -33.14; %  (-153.1, 86.84)
p41 =   1.604e-06; %  (6.819e-08, 3.14e-06)
p32 =   -3.64e-05; %  (-0.0001186, 4.583e-05)
p23 =   0.0009431; %  (-0.004549, 0.006435)
p14 =      0.2545; %  (-0.1538, 0.6629)
p05 =       14.26; %  (-28.97, 57.48)


%Defining solubility curves
w_AS = (x(:,8)-m_H2O)./x(:,8);
T_L = x(:,6);

Solubility = p00 + p10.*T_L + p01.*w_AS + p20.*(T_L.^2) + p11.*T_L.*w_AS + p02.*(w_AS.^2) + ...
    p30.*(T_L.^3) + p21.*(T_L.^2).*w_AS + p12.*T_L.*(w_AS.^2) + p03.*(w_AS.^3) + p40.*(T_L.^4) + ...
    p31.*(T_L.^3).*w_AS + p22.*(T_L.^2).*(w_AS.^2) + p13.*T_L.*(w_AS.^3) + p04.*(w_AS.^4) + ...
    p41.*(T_L.^4).*w_AS + p32.*(T_L.^3).*(w_AS.^2) + p23.*(T_L.^2).*(w_AS.^3) + p14.*T_L.*(w_AS.^4) + p05.*(w_AS.^5);
% Solubility = exp(p00 + p10.*(1./x(:,6)) ...
%                      + p01.*((x(:,8)-m_H2O)./x(:,8)).*100 ...
%                      + p20.*(1./x(:,6)).^2 ...
%                      + p11.*(1./x(:,6)).*((x(:,8)-m_H2O)./x(:,8)).*100 ...
%                      + p02.*(((x(:,8)-m_H2O)./x(:,8)).*100).^2); % kg Xyl/kg Solvent
                 
% Solubility = exp(p00 + p10.*(1./x(:,6)) ...
%                      + p20.*(1./x(:,6)).^2); % kg Xyl/kg Solvent
                 
Soluteconc = x(:,5)./ x(:,8);

SupSratio = Soluteconc./Solubility;

% figure(2)
% hold on
% plot(t,x(:,6))
% plot(t,x(:,7))
% xlabel('Time (s)')
% ylabel('Temperature (\circC)')
% legend('Bulk temperature','Cooling temperature')


% figure(3)
% hold on
% plot(t,x(:,5))
% xlabel('Time (s)')
% ylabel('Solute mass')


% figure(4)
% hold on
% yyaxis left
% % plot(t,x(:,5))
% plot(t,Solubility)
% hold on
% plot(t,Soluteconc)
% hold on
% xlabel('Time (s)')
% ylabel('Concentration (g/g)')
% yyaxis right
% plot(t,SupSratio)
% %ylim([0.8 1.2])
% ylabel('Supersaturation ratio')
% legend('Saturation conc.', 'Solute conc.','SupSat ratio')


% Sizing
V_crystallizer = Sizing(m_liquid, rho_liquid, tf);

% Costing
FCI = costing_crystallization_xylitol(m_liquid, tf);

% output
mf(1) = m_cryst;
mf(2) = m_AS;

stats_out = [x(end,6)];

hf = H_C;

design = [V_crystallizer, FCI];


end

%% Sizing
function V_crystallizer = Sizing(m_liquid, rho_liquid, tf)

% m_liquid = m_liquid / 1000; % [t]
% rho_liquid = rho_liquid / 1000; % [t/m3]

time = tf/3600; % time in h

% Volumetric capacity per hour
% m_daily = m_liquid / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_liquid / time;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly = m_hourly / rho_liquid;

V_crystallizer = V_total_hourly * time;

end

%% Costing
function FCI = costing_crystallization_xylitol(m_liquid, tf)

time = tf/3600; % time in h

% Capacity own plant
CP = m_liquid/time; % kg/h

% Capacity NREL Plant
CP0 = 162; % kg/h

% Fixed capital investment for unit
FCI00 = 60000; % $(2010)
n = 19; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end

