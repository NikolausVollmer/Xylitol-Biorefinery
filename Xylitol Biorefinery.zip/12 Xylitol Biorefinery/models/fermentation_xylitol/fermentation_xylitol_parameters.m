function par = fermentation_xylitol_parameters()
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

q_s_max_Glu = 3.276;
q_s_max_Xyl = 0.2145;
q_s_max_Xyo = q_s_max_Xyl;

K_Glu = 49.9814;
K_Xyl = 0.4588;
K_Xyo = K_Xyl;

K_I_Glu = 0.6114;
K_I_Xyl = 0.9295;

a_Glu = 3.536;
ms_Glu = 1.4867e-5;

a_Xyl = 3.5748;
b_Xyl = 4.5582e-11;
ms_Xyl = 2.0635e-11;

a_Xyo = 4.6552;
ms_Xyo = 1.1361e-5;

alpha = 4.4321e-6;
beta = 0.0859;

par = [q_s_max_Glu, q_s_max_Xyl, q_s_max_Xyo, K_Glu, K_Xyl, K_Xyo,...
       K_I_Glu, K_I_Xyl, a_Glu, ms_Glu, a_Xyl, b_Xyl, ms_Xyl, a_Xyo, ms_Xyo, alpha, beta];

end

