function [m_out, c_out, stats_out, mf, hf, design] = crystallization_model_succ(m_in, c_in, stats)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
% global T0 Tf Fin_a tfinal Cini F_j V_j rho_w rho_a Cp_w Cp_a X_a w_a rho_solv MW_w MW_a Vini rho_c DHc ka kv MW_c L_min L_max L0 Grow U Tc A Nuc xini

%% INPUT
% mass
m_liquid = m_in / 300 / 24 * stats(1); % scale from total mass per mass of batch

% Stats 
T0_L = stats(2);              % Initial temperature - [degC]
tf = stats(1)*3600;           % Batch time [s]
F_AS = stats(4);              % Flowrate of antisolvent - [kg/s]
F_C = stats(5);  % Coolant flowrate [kg/s]
T0_C = stats(3);              % Initial coolant temperature - [degC]
rho_liquid = stats(6);        % Density of the incoming broth - [kg/m3]

N = 400;                      % Impeller speed - [rpm]

% Parameters for solvent (H2O) and antisolvent (Ethanol)
rho_L = 1000;                 % Density water - [kg/m3]
rho_AS = 789;                 % Density antisolvent (Ethanol) - [kg/m3]
Mw_L = 18.02;                 % Molecular weight water - [g/mol]
Mw_AS = 46.07;                % Molecular weight antisolvent - [g/mol]
Cp_L = 4184;                  % Constant liquid heat capacity water - [J/kg/degC]
Cp_AS = 2460;                 % Constant liquid heat capacity antisolvent - [J/kg/degC]
V0 = m_liquid/rho_L;          % Initial liquid volume - [m3]


c_H2O = c_in(17);            % Concentration of water in liquid - [g H2O/100g liquid]
m_H2O = m_liquid * c_H2O / 100;     % Mass of water in liquid - [kg]

X_AS = c_in(17)/c_H2O;
w_AS = Mw_AS*X_AS / ((Mw_AS-Mw_L)*X_AS + Mw_L); % Weight fraction of antisolvent in solvent - [-]
rho_Sol = 1 / (w_AS/rho_AS + (1-w_AS)/rho_L);   % Density of solvent (H2O + EtOH) - [kg/m3]

par_solvent = [rho_L, rho_AS, Mw_L, Mw_AS, Cp_L, Cp_AS];

% Parameters for xylitol crystals
rho_Sac = 1560;                 % Density pf succinic   [kg/m3]     % according to GESTIS database
DH_fus_Sac = 32.94*10^3;        % Enthalpy of fusion/crystallization of xylitol [kJ/kmol], according to DIPPR  2018  
ka = 2.0;                       % Surface shape factor      % Mullin, Whiting 1980; Industrial Crystallization Process Monitoring and Control, 2012                       
kv = 0.33;                      % Volumetric shape factor   % Qiu,Rasmuson, 1991                           
Mw_Sac = 118.088;               % Molecular weight succinic acid [g/mol]  % according to DIPPR 2018
% L_min = 10e-6;                % Minimum crystal size [m]                 
% L_max = 1050e-6;              % Maximum crystal size [m]                
L0 = 5e-6;                      % Critical nuclei size [m]                 
% L_seed_max = 10e-6;           % Maximum crystal size in seed   [m]                 

% Parameters for seed mass
seed_mass = 0.0025;              % seed mass of succinic acid crystals [kg Succinic Acid/kg solvent]      
seed_mean = 755e-6;              % Mean seed size [m]
m0_Sac = c_in(19)*m_liquid/100; % Initial mass of solute [kg Succinic Acid]
% Cini = m0_Suc/V0;               % Initial volumetric concentration of succinic acid [kg Succinic Acid/m3]
m0_cryst = seed_mass * m_H2O;

par_Sac = [rho_Sac, DH_fus_Sac, ka, kv, Mw_Sac, L0];

% Initial seed parameters (ask Merve?)
mu0_ini = (seed_mass * rho_Sol/rho_Sac) / ((seed_mean/2)^3 * pi * 4/3*kv);  % [#/m3] 
mu1_ini = mu0_ini * seed_mean;                                              % [m/m3]
mu2_ini = mu0_ini * (seed_mean/2)^2 * pi * 4 * ka;                          % [m2/m3]
mu3_ini = mu0_ini * (seed_mean/2)^3 * pi * 4/3 * kv;                        % [m3/m3]

% Parameters for cooling liquid and crystallizer design
Vf = V0 + F_AS/rho_AS * tf;                   % Final volume of liquid with crystals - [m3]
H = 0.5;                                      % Heigth of crystallizer [m]
D = 2 * sqrt(Vf/pi/H);                        % Diameter of crystallizer[m]
U = 1275;                                     % Heat transfer coefficient [W/m^2C]
V_j = pi * H/4 * (((D + 2*0.010)^2) - (D^2)); %V_j=pi*0.6/4*(((0.642+2*0.010)^2)-(0.642^2));   %[m^3]
A = pi * D * H;                               % A=pi*0.642*0.6;   %Heat transfer area [m^2]  A=D*H*h (D and H is working area of crystallizer)

par_design = [U, T0_C, A, F_C, V_j];

%% Stats for Kinetic model
stats = [m_H2O, F_AS, V0, m0_Sac, N, m0_cryst];

%% Kinetic Model - Method of Moments
options = odeset('RelTol',1e-7,'AbsTol',1e-8,'NonNegative',[1:8]);
xini = [mu0_ini mu1_ini mu2_ini mu3_ini m0_Sac T0_L T0_C m_H2O];
time = linspace(0,tf,100);
[t x] = ode45(@crystallization_succ_mom, time, xini, options, par_solvent, par_Sac, par_design, stats);


%% Output masses
% mass of crystals
m_cryst_single = x(1,5) - x(end,5);
m_cryst = m_cryst_single * 300 * 24 / (tf/3600);

% output mass = input mass + antisolvent
m_slurry = m_liquid + F_AS*tf - m_cryst_single;
m_out = m_slurry * 300 * 24 / (tf/3600);

% mass of antisolvent
m_AS = F_AS*tf * 300 * 24 / (tf/3600);

% output concentrations
% c_out([1:20]) = c_in([1:20]);

mm_out = c_in * m_in / 100;
mm_out(19) = mm_out(19) - m_cryst;

c_out = mm_out ./ sum(mm_out) .* 100;

%% Energy balance
FH_C = F_C * Cp_L * 0.001 * (x(:,7) - T0_C);
H_C = mean(FH_C) * tf;

Tf = x(end,6);
stats_out = [Tf];


% 
% %x(:,1)=mu0 x(:,2)=mu1 (total L of crystals), x(:,3)=mu2 (Total A of crystals, x(:,4)=mu3 (Total V of crystals)
% %x(:,5)=mu4, x(:,6)=m (xylitol mass liquid phase g), x(:,7)=T (temperature
% %in crystallizer), x(:,8)=Tc, x(:,9)=mass in tank
% 
% % m_end = x(end,6); % Final mass of xylitol in liquid phase
% % 
% % %Calculating yield and mass of xylitol crystals per solvent volume
% % yield = (x(1,6)-x(end,6))/(x(1,6));       
% % Mass_c = x(end,6);                      %kg xylitol
% % MeanSize = x(end,2)/x(end,1);           %[m]
% % 
%% Solubility
p1 =   9.504e-07; %  (7.674e-08, 1.824e-06)
p2 =    4.41e-06; %  (-7.7e-05, 8.582e-05)
p3 =    0.001628; %  (-0.0008373, 0.004093)
p4 =     0.02543; %  (0.00122, 0.04963)

%Solubility
Solubility = p1.*x(:,6).^3 + p2.*x(:,6).^2 + p3.*x(:,6) + p4;
                 
Soluteconc = x(:,5)./ x(:,8);

SupSratio = Soluteconc./Solubility;

% figure(7)
% hold on
% plot(t,x(:,6))
% plot(t,x(:,7))
% xlabel('Time (s)')
% ylabel('Temperature (\circC)')
% legend('Bulk temperature','Cooling temperature')
% hold off

% figure(8)
% hold on
% plot(t,x(:,5))
% xlabel('Time (s)')
% ylabel('Solute mass')
% hold off

% figure(9)
% hold on
% yyaxis left
% % plot(t,x(:,5))
% plot(t,Solubility)
% hold on
% plot(t,Soluteconc)
% hold on
% xlabel('Time (s)')
% ylabel('Concentration (g/g)')
% yyaxis right
% plot(t,SupSratio)
% %ylim([0.8 1.2])
% ylabel('Supersaturation ratio')
% legend('Saturation conc.', 'Solute conc.','SupSat ratio')
% hold off

% Sizing
V_crystallizer = Sizing(m_liquid, rho_liquid, tf);

% Costing
FCI = costing_crystallization_succ(m_liquid, tf);

% output
stats_out = [x(end,6)];

mf(1) = m_cryst;
mf(2) = m_AS;

hf = H_C;

design = [V_crystallizer, FCI];


end

%% Sizing
function V_crystallizer = Sizing(m_liquid, rho_liquid, tf)

% m_liquid = m_liquid / 1000; % [t]

time = tf/3600; % time in h

% Volumetric capacity per hour
% m_daily = m_liquid / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_liquid / time;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly = m_hourly / rho_liquid;

V_crystallizer = V_total_hourly * time;

end

%% Costing
function FCI = costing_crystallization_succ(m_liquid, tf)

time = tf/3600; % time in h

% Capacity own plant
CP = m_liquid/time; % kg/h

% Capacity NREL Plant
CP0 = 162; % kg/h

% Fixed capital investment for unit
FCI00 = 60000; % $(2010)
n = 19; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end
