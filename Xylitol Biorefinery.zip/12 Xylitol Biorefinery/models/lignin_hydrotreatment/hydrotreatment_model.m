function [m_kerosene, c_out, mf, hf, design] = hydrotreatment_model(m_biooil,c_in,stats)
%PYROLYSIS MODEL FOR LIGNOCELLULOSIC BIOMASS PYROLYSIS 
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 04.03.2021
% calls to:
%  - pyrolysis_kinetics
%  - pyrolysis_parameters
%  - pyrolysis_mw

%% Molar masses
MW = hydrotreatment_mw();

%% Input masses and molar flowrate
x0(1) = sum(c_in([14:24])) * 1000 * m_biooil / MW(1); % Oxygenates in mol
x0(2) = sum(c_in([34:38])) * 1000 * m_biooil / MW(2); % Gaseous products in mol
x0(3) = 0;                                            % Hydrocarbons in mol
x0(4) = sum(c_in([25:33])) * 1000 * m_biooil / MW(4); % Alkylphenolics in mol
x0(5) = 0;                                            % Alkylaromates in mol

N = sum(x0); % Total molar flow in mol/h
x0 = x0 ./ N;

% % Hydrogen requirement
% Hreq = 6 * x0(1) + x0(4); % Requirement based on stoichiometry
% Hreq = 2 * Hreq;          % Operational excess
% x0(8) = Hreq;
% 
% x0(1:7) = x0(1:7) ./sum(x0(1:7));
% x0(8:9) = 0;

%% State Variables, flow and gas velocity
T = stats(1);
length = stats(2); % Bed length in m
diameter = stats(3); % Bed diameter in m
eps_bed = stats(4); %  Bed porosity
rho_cat = 1000; % kg/m3
rho_gas = 875; % kg/m3
T0 = stats(5); % degC

m_biooil = m_biooil / 300 / 24 ; % scale from total mass per year to mass per hour

V = m_biooil / rho_gas; % m3/h
v = V / (eps_bed * pi/4 * diameter^2); % Gas velocity in m/h


spacetime = rho_cat / (rho_gas * v) * length; % normalized space time in g Cat * h/g Oil

stats = [T,v,rho_cat,rho_gas];

%% Length
% Time of residence
tspan = linspace(0,spacetime,100);

%% Reaction
options = odeset('RelTol',1e-7,'AbsTol',1e-8);
[~,y] = ode45(@hydrotreatment_kinetics,tspan,x0,options,stats);


%% Output masses
% c_out based on 100g biomass dry
y_res = y(end,:);

% Hydrogen requirement & water production
dOX = (y_res(1) - x0(1)) * N;
dGC = (y_res(2) - x0(2)) * N;
dHC = (y_res(3) - x0(3)) * N;
dPH = (y_res(4) - x0(4)) * N;
dAR = (y_res(5) - x0(5)) * N;

dH2 = dOX * 15/8 - dHC * 8/3;
dH2O = -dOX * 22/8 - dPH * 2;

dH2 = dH2 * 2.016 / 1000;
dH2O = dH2O * 18.015 / 1000;

H2_0 = c_in(39) * m_biooil;
H2O_0 = c_in(40) * m_biooil;

H2_supply = H2_0 + abs(dH2);
H2O_product = H2O_0 + dH2O;

% absolute mass of components
m_res = y_res .* N .* MW(1:5) / 1000;
m_res(6) = 0; % Hydrogen
m_res(7) = c_in(40) + H2O_product;
m_kerosene = sum(m_res);
c_out = m_res ./ m_kerosene;

% plot(tspan,y)

% Energy Balance
H_R = hydrotreatment_energy_balance(m_biooil, H2_supply, T, T0);


%% Sizing
V_reactor = pi * (diameter/4)^2 * length;

% Function output
mf = H2_supply;
hf = H_R;

% Costing
FCI = costing_hydrotreatment(m_biooil);


design = [V_reactor, FCI];

end

%% ENERGY Balance
function H_R = hydrotreatment_energy_balance(m_biooil, H2_supply, T, T0)
Cp = 2.185;     % heat capacity of biooil in kJ/kg/K
Cp_H2 =  28.84 / 2;       % heat capacity of hydrogen in kJ/kg/K (NIST

H_R = (m_biooil * Cp + H2_supply * Cp_H2) * (T0 - T); % Heating enthalpy in kJ

end

%% Costing
function FCI = costing_hydrotreatment(m_biooil)

m_hourly = m_biooil; % m_biooil comes in as kg/h

% m_daily = m_biooil/300; % assuming the plant operates 300 d/y [t/d]
% m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 58333; % kg/h

% Fixed capital investment for unit
FCI00 = 3500000; % $(2010)
n = 21; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;

end


