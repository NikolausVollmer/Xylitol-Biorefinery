function [m_liquid, c_out_l, m_vapor, c_out_v, m_prefrac, c_out_p, mf, hf, design] = fractionation_model(m, c_in, stats, Aspen)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Input
% Broth mass
m_hfoil = m;        % Broth mass in kg

% Mass fractions
c_in = abs(c_in);

x_OX = c_in(1);         % Fraction of oxygenated compounds in hfoil - [wt% hfoil]
x_GC1 = c_in(2)*0.0671; % Concentration of hydrogen (GC) in hfoil  - [wt% hfoil]
x_GC2 = c_in(2)*0.9329; % Concentration of carbon monoxide (GC) in hfoil  - [wt% hfoil]
x_HC = c_in(3);         % Concentration of hydrocarbons in hfoil  - [wt% hfoil]
x_PH = c_in(4);         % Concentration of phenolics in hfoil - [wt% hfoil]
x_AR = c_in(5);         % Concentration of aromates in hfoil - [wt% hfoil]
x_H2 = c_in(6);         % Concentration of hydrogen in hfoil - [wt% broth]
x_H2O = c_in(7);        % Concentration of water in hfoil - [wt% broth]

% Stats
T_in = stats(1); % temperature of ingoing hfoil -  [degC]
p_in = stats(2); % pressure of ingoing hfoil -  [bar]
p_f1 = stats(3); % pressure of first flash drum - [bar]
p_f2 = stats(4); % pressure of second flash durm - [bar]

%% ASPEN PLUS simulation
% Feed mass
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\TOTFLOW\MIXED').Value = m_hfoil; % Broth

% Mass Fractions
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\ACETO-01').Value = x_OX; % oxygenated compounds fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\HYDRO-01').Value = x_GC1 + x_H2; % hydrogen fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\CARBO-01').Value = x_GC2; % carbon monoxide fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\CYCLO-01').Value = x_HC; % hydrocarbons fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\1:2:4-01').Value = x_PH; % phenolics fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\INDAN-01').Value = x_AR; % aromates fraction
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\FLOW\MIXED\WATER').Value = x_H2O; % water fraction

% Stats
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\TEMP\MIXED').Value = T_in + 273.15; % Input temperature of stream
Aspen.Tree.FindNode('\Data\Streams\FEED\Input\PRES\MIXED').Value = p_in; % Input temperature of stream
Aspen.Tree.FindNode('\Data\Blocks\PREFRAC\Input\PRES').Value = p_f1; % Vapor fraction
Aspen.Tree.FindNode('\Data\Blocks\FRAC\Input\PRES').Value = p_f2; % Vapor fraction


% Aspen.Reinit; % Reinitialise simulation
Aspen.Engine.Run2(1);
% 
while Aspen.Engine.IsRunning == 1 % 1 --> If Aspen is running; 0 ---> If Aspen stop.
    pause(3.0);
end

%% ASPEN PLUS output
% Prefrac fraction
m_prefrac = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFLMX\MIXED').Value; % * 3600; % Mass flow liquid out

z_OX_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\ACETO-01').Value; % oxygenated compounds fraction
z_GC1_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\HYDRO-01').Value; % hydrogen fraction
z_GC2_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\CARBO-01').Value; % carbon monoxide fraction
z_HC_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\CYCLO-01').Value; % hydrocarbons fraction
z_PH_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\1:2:4-01').Value; % phenolics fraction
z_AR_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\INDAN-01').Value; % aromates fraction
z_H2O_out = Aspen.Tree.FindNode('\Data\Streams\CFLASH\Output\MASSFRAC\MIXED\WATER').Value; % water fraction

% Vapor fraction
m_vapor = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFLMX\MIXED').Value; % * 3600; % Mass flow vapor out

y_OX_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\ACETO-01').Value; % oxygenated compounds fraction
y_GC1_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\HYDRO-01').Value; % hydrogen fraction
y_GC2_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\CARBO-01').Value; % carbon monoxide fraction
y_HC_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\CYCLO-01').Value; % hydrocarbons fraction
y_PH_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\1:2:4-01').Value; % phenolics fraction
y_AR_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\INDAN-01').Value; % aromates fraction
y_H2O_out = Aspen.Tree.FindNode('\Data\Streams\VAPOR\Output\MASSFRAC\MIXED\WATER').Value; % water fraction

% Liquid fraction
m_liquid = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFLMX\MIXED').Value; % * 3600; % Mass flow vapor out

x_OX_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\ACETO-01').Value; % oxygenated compounds fraction
x_GC1_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\HYDRO-01').Value; % hydrogen fraction
x_GC2_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\CARBO-01').Value; % carbon monoxide fraction
x_HC_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\CYCLO-01').Value; % hydrocarbons fraction
x_PH_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\1:2:4-01').Value; % phenolics fraction
x_AR_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\INDAN-01').Value; % aromates fraction
x_H2O_out = Aspen.Tree.FindNode('\Data\Streams\LIQUID\Output\MASSFRAC\MIXED\WATER').Value; % water fraction

% Energies
H_Pcool = Aspen.Tree.FindNode("\Data\Blocks\PREFRAC\Output\QNET").Value * 0.001 * 3600;    % kJ
H_Fcool = Aspen.Tree.FindNode("\Data\Blocks\FRAC\Output\QNET").Value * 0.001 * 3600;    % kJ

H_ext = H_Pcool + H_Fcool;

%% Output concentrations
c_out_p = [z_OX_out, z_GC1_out, z_GC2_out, z_HC_out, z_PH_out, z_AR_out, z_H2O_out];
c_out_v = [y_OX_out, y_GC1_out, y_GC2_out, y_HC_out, y_PH_out, y_AR_out, y_H2O_out];
c_out_l = [x_OX_out, x_GC1_out, x_GC2_out, x_HC_out, x_PH_out, x_AR_out, x_H2O_out];

% stats_out = [T_liquid, T_vapor];
stats_out = [];

[V_stage1, V_stage2] = Sizing(m_prefrac, m_vapor, m_liquid);

FCI = costing_fractionation(m_prefrac, m_vapor, m_liquid);


% Function output
mf = 0;
hf = H_ext;

design(1) = V_stage1;
design(2) = V_stage2;
design(3) = FCI;

end

function [V_stage1, V_stage2] = Sizing(m_prefrac, m_vapor, m_liquid)

m_stage1 = (m_prefrac + m_vapor + m_liquid) / 1000; % mass gas stage 1 [t]
m_stage2 = (m_vapor + m_liquid) / 1000; % mass gas stage 1 [t]

rho_gas = 0.875; % t/m3 - Pro/II !!! CHECK AGAIN

time1 = 0.5; % [h]
time2 = 0.5; % [h]

% Volumetric capacity per hour
m1_daily = m_stage1 / 300; % assuming the plant operates 300 d/y [t/d]
m1_hourly = m1_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

m2_daily = m_stage2 / 300; % assuming the plant operates 300 d/y [t/d]
m2_hourly = m2_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

V1_total_hourly = m1_hourly / rho_gas; % [m3/h]
V2_total_hourly = m2_hourly / rho_gas; % [m3/h]

V_stage1 = V1_total_hourly * time1;
V_stage2 = V2_total_hourly * time2;

end

%% Costing
function FCI = costing_fractionation(m_prefrac, m_vapor, m_liquid)

m_stage1 = (m_prefrac + m_vapor + m_liquid); % mass gas stage 1 [kg]
m_stage2 = (m_vapor + m_liquid); % mass gas stage 1 [kg]

m1_daily = m_stage1 / 300; % assuming the plant operates 300 d/y [t/d]
m1_hourly = m1_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

m2_daily = m_stage2 / 300; % assuming the plant operates 300 d/y [t/d]
m2_hourly = m2_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

% Capacity own plant
CP1 = m1_hourly; % kg/h
CP2 = m2_hourly; % kg/h

% Capacity NREL Plant
CP0 = 5721; % kg/h

% Fixed capital investment for unit
FCI001 = 98000; % $(2002)
FCI002 = 67300; % $(2002)

n = 19; % ten years difference 2020 - 2010

FCI01 = FCI001 * (1+0.01)^n;
FCI02 = FCI002 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI1 = FCI01 * (CP1/CP0)^x;
FCI2 = FCI02 * (CP2/CP0)^x;

FCI = FCI1 + FCI2;

end

