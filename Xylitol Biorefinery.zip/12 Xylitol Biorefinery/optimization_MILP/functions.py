"""
FUNCTIONS
Created on Tue Oct 06 2020
@author: nikov@kt.dtu.dk

File containing functions for the MILP solution to superstructure optimization

Functions:
- Data import - "import_csv"
"""

import pandas as pd
import numpy as np


## 1. DATA IMPORT
def import_csv(dictData):
    filepath_s = dictData["filepath_s"]
    filepath_p = dictData["filepath_p"]
    dim = dictData["dim"]

    frame_s = pd.read_csv(filepath_s)
    frame_p = pd.read_csv(filepath_p)

    # read data from csv file: indices, input (X), output for objective(Y), output for constraints(C)
    setS = frame_s.to_numpy()[:,1:]
    setS_x = frame_s.to_numpy()[:, 1:1+dim[0]]
    setS_y = frame_s.to_numpy()[:, 1+dim[0]:1+dim[0]+dim[1]]

    ysimplices = np.reshape(setS,(int(len(setS)/(dim[0]+dim[1])),int(dim[0]+dim[1]),int(dim[0]+dim[1])))
    simplices = np.reshape(setS_x,(int(len(setS_x)/(dim[0]+dim[1])),int(dim[0]+dim[1]),dim[0]))
    attributes = np.reshape(setS_y,(int(len(setS_y)/(dim[0]+dim[1])),int(dim[0]+dim[1]),dim[1]))

    setP = frame_p.to_numpy()[:,1:]
    setP_x = frame_p.to_numpy()[:, 1:1+dim[0]]
    setP_y = frame_p.to_numpy()[:, 1+dim[0]:1+dim[0]+dim[1]]

    # store data in dictionary
    dictData["ysimplices"] = ysimplices
    dictData["simplices"] = simplices
    dictData["attributesS"] = attributes

    dictData["ypoints"] = setP
    dictData["points"] = setP_x
    dictData["attributesP"] = setP_y

    return dictData