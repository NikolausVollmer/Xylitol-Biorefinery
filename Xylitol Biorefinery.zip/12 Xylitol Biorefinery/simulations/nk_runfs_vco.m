function [KPI, Mass] = nk_runfs_vco(x,space,configID,Aspen,mf,yp)
    % simulate a single row
    addpath(genpath('../models'))
    designrow = table2struct(array2table(x, 'VariableNames', space.ParNames));
    struct2vars(designrow);
    
    m = 0;
    c = [];
    Stats = [];
    
    Mass.Xylitol = 0;
    Mass.Succinic_Acid = 0;
    Mass.Kerosene = 0;
    Mass.Flue_Gas = 0;
    Mass.Feedstock = mf;
    
    KPI.FCI = 0;
    
    m_wwt = 0;
    
    m_cell_biomass = 0;
    m_lignin = 0;
    m_titr = 0;
    m_nitro = 0;
    m_acid = 0;
    m_base = 0;
    m_enzyme = 0;
    m_water = 0;
    m_antisolvent = 0;
    m_co2_succinic_acid = 0;
    m_co2_biogen = 0;
    m_h2 = 0;
    m_LF_v = 0;
    
    m_lpsteam = 0;
    m_mpsteam = 0;
    m_cooling = [];
    m_ccooling = 0;
    m_fg = 0;
    m_ca = 0;
    
    Time = 0;
    
    % Biorefinery capacity % feedstock composition
    m_feedstock = mf; % kg/y dry wheat straw
    c_feedstock = [26.844 0 40.74 0 3.3555 0 3.3555 0 0 0 0 0 25.705 0 0 0 0 0 0 0 0];
    
    m = m_feedstock;
    c = c_feedstock;
    
    % Heat calculations
    h_lp = 2745.9 - 632.25; % kJ/kg from VDI (150 degC)
    h_mp = 2797.4 - 897.73; % kJ/kg from VDI (210 degC)
    h_cw = 63.078; % kJ/kg from VDI
    h_ccw = 21.118; % kJ/kg from VDI
    h_fg = 50000; % kJ/kg from engineeringtoolbox.com
    h_ca = 453; % kJ/kg from VDI
    
    cp_water = 4.19; % kJ/kg/K
    
    for i = 1:length(configID)
        model = cell2mat(configID(i));
    
        switch model
            case 'PT'
                m_PT_in = m;
                c_PT_in = c;
                
                phi_PT = 0.1;
                
                stats_PT_in = [t_PT, T_PT, acid, phi_PT];
                
                [m_PT_l_out, c_PT_l_out, m_PT_s_out, c_PT_s_out, mf_PT, hf_PT, design_PT] = pretreatment_model(m_PT_in, c_PT_in, stats_PT_in);
                
                m = m_PT_l_out;
                c = c_PT_l_out;
                
                KPI.FCI = KPI.FCI + design_PT(2);
                m_water = m_water + mf_PT(1);
                Mass.Acid = m_acid + mf_PT(2);

                m_mpsteam = m_mpsteam + hf_PT(1)/h_mp; % kg/y
                m_cw_PT = abs(hf_PT(2))/(cp_water * 5); % kg/y, delta T = 5
                m_cooling = [m_cooling, m_cw_PT]; % kg/y
               
                
            case 'UH'
                m_UH_in = m;
                c_UH_in = c;
                
                T_in_UH = 40;
                T_out_UH = 30;
                
                stats_UH_in = [v_UH, T_in_UH, T_out_UH];
                
                [m_UH_l_out, c_UH_l_out, m_UH_v_out, c_UH_v_out, stats_UH_out, mf_UH, hf_UH, design_UH] = evaporation_model_xylitol(m_UH_in, c_UH_in, stats_UH_in, Aspen.HF);
                
                m = m_UH_l_out;
                c = c_UH_l_out;
                Tl_UH = stats_UH_out(1);
                Tv_UH = stats_UH_out(2);
                
                KPI.FCI = KPI.FCI + design_UH(2);

                m_wwt = m_wwt + m_UH_v_out;
                m_lpsteam = m_lpsteam + hf_UH(1)/h_lp;
                m_cw_UH = (abs(hf_UH(2))+abs(hf_UH(3)))/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_UH];
                
                
            case 'FX'
                m_FX_in = m;
                c_FX_in = c;
                
                inoc_FX = 3/Vfrac_FX;
                tfend_FX = 0.95;
                
                stats_FX = [t_FX, inoc_FX, Vfrac_FX, tfstart_FX, tfend_FX];
                
                [m_FX_out, c_FX_out, mf_FX, hf_FX, design_FX] = fermentation_model_xylitol(m_FX_in, c_FX_in, stats_FX);

                m = m_FX_out;
                c = c_FX_out;
                
                KPI.FCI = KPI.FCI + design_FX(2);

                Mass.Nitrogen = m_nitro + mf_FX(2);
                Mass.Titrant = m_titr + mf_FX(3); 
                m_cell_biomass = m_cell_biomass + mf_FX(6);
                Mass.CO2_biogen = m_co2_biogen + mf_FX(4) * 0.05;
                
                m_cw_FX = abs(hf_FX)/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_FX];
                
                
            case 'EX'
                m_EX_in = m;
                c_EX_in = c;
                
                t_EX = 1;
                T_EX_in = 30;
                T_EX_out = 40;
                
                stats_EX_in = [v_EX,T_EX_in,T_EX_out];
                
                [m_EX_l_out, c_EX_l_out, m_EX_v_out, c_EX_v_out, stats_EX_out, mf_EX, hf_EX, design_EX] = evaporation_model_xylitol(m_EX_in, c_EX_in, stats_EX_in, Aspen.HF);
                
                m = m_EX_l_out;
                c = c_EX_l_out;
                                
                KPI.FCI = KPI.FCI + design_EX(2);
                
                m_wwt = m_wwt + m_EX_v_out;
                m_lpsteam = m_lpsteam + hf_EX(1)/h_lp;
                
                m_cw_EX = (abs(hf_EX(2)) + abs(hf_EX(3)))/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_EX];   
                
                
            case 'CX1'
                m_CX1_in = m;
                c_CX1_in = c;
                
                Ti_CX1 = 40;
                TC_CX1 = 15;
                FAS_CX1 = 0;
                rho_liquid_CX1 = 1200;
                
                stats_CX1 = [t_CX1, Ti_CX1, TC_CX1, FAS_CX1, FC_CX1, rho_liquid_CX1];
                
                [m_CX1_out, c_CX1_out, stats_CX1_out, mf_CX1, hf_CX1, design_CX1] = crystallization_model_xylitol(m_CX1_in, c_CX1_in, stats_CX1);
                
                m = m_CX1_out;
                c = c_CX1_out;
                Tf_CX1 = stats_CX1_out(1);
                
                Mass.Xylitol = Mass.Xylitol + mf_CX1(1);
                KPI.FCI = KPI.FCI + design_CX1(2);
                
                m_wwt = m_wwt + m_CX1_out;
                
                m_cw_CX1 = abs(hf_CX1)/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_CX1];
                
                                
            case 'CX2'
                m_wwt = m_wwt - m_CX1_out;
                
                m_CX2_in = m;
                c_CX2_in = c;
                
                Ti_CX2 = Tf_CX1;
                TC_CX2 = Tf_CX1;
                FC_CX2 = 0;
                rho_liquid_CX2 = 1200; % kg/m3
                
                stats_CX2 = [t_CX2, Ti_CX2, TC_CX2, FAS_CX2, FC_CX2, rho_liquid_CX2];
                
                [m_CX2_out, c_CX2_out, stats_CX2_out, mf_CX2, hf_CX2, design_CX2] = crystallization_model_xylitol(m_CX2_in, c_CX2_in, stats_CX2);
                
                m = m_CX2_out;
                c = c_CX2_out;
                
                Mass.Xylitol = Mass.Xylitol + mf_CX2(1);
                KPI.FCI = KPI.FCI + design_CX2(2);
                
                m_wwt = m_wwt + m_CX2_out;
                Mass.Ethanol = m_antisolvent + mf_CX2(2);
                
                
            case 'EH'
                m_EH_in = m_PT_s_out; % t/h, equals to 1e6 t/y (according to IEA report)
                c_EH_in = c_PT_s_out;
                
                T_EH = 52.5;
                pH_EH = 5;
                T_PT_out = 40;
                
                stats_EH_in = [t_EH, T_EH, pH_EH, T_PT_out];
                
                [m_EH_l_out, c_EH_l_out, m_EH_s_out, c_EH_s_out, mf_EH, hf_EH, design_EH] = hydrolysis_model(m_EH_in, c_EH_in, stats_EH_in);
                
                m = m_EH_l_out;
                c = c_EH_l_out;
                
                KPI.FCI = KPI.FCI + design_EH(2);
                
                m_lignin = m_lignin + m_EH_s_out;
                Mass.Titrant = m_base + mf_EH(2);
                Mass.Enzyme = m_enzyme + mf_EH(3);
                m_water = m_water + mf_EH(1) + mf_EH(4);
                
                m_lpsteam = m_lpsteam + hf_EH(1)/h_lp;
                
                m_cw_EH = abs(hf_EH(2))/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_EH];
                
                                
            case 'UC'
                m_UC_in = m;
                c_UC_in = c;
                
                T_in_UC = 40;
                T_out_UC = 30;
                
                stats_UC_in = [v_UC, T_in_UC, T_out_UC];                
                
                [m_UC_l_out, c_UC_l_out, m_UC_v_out, c_UC_v_out, stats_UC_out, mf_UC, hf_UC, design_UC] = evaporation_model_succ(m_UC_in, c_UC_in, stats_UC_in, Aspen.CF);
                
                m = m_UC_l_out;
                c = c_UC_l_out;
                Tl_UC = stats_UC_out(1);
                Tv_UC = stats_UC_out(2);
                                
                KPI.FCI = KPI.FCI + design_UC(2);
                
                m_wwt = m_wwt + m_UC_v_out;
                m_lpsteam = m_lpsteam + hf_UC(1)/h_lp;
                
                m_cw_UC = (abs(hf_UC(2)) + abs(hf_UC(3)))/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_UC];  
                
                
            case 'FS'
                m_FS_in = m;
                c_FS_in = c;
                
                inoc_FS = 3/Vfrac_FS;
                tfend_FS = 0.95;
                
                stats_FS = [t_FS, inoc_FS, Vfrac_FS, tfstart_FS, tfend_FS];
                               
                [m_FS_out, c_FS_out, mf_FS, hf_FS, design_FS] = fermentation_model_succ(m_FS_in, c_FS_in, stats_FS);
                                
                KPI.FCI = KPI.FCI + design_FS(2);
                
                m = m_FS_out;
                c = c_FS_out;
                
                m_cell_biomass = m_cell_biomass + mf_FS(5);
                Mass.Titrant = m_titr + mf_FS(3);
                Mass.Nitrogen = m_nitro + mf_FS(2);
                Mass.CO2_succ_in = m_co2_succinic_acid + mf_FS(1);
%                 KPI.Mass_CO2_biogen = m_co2_biogen + mf_FS(4);
                Mass.CO2_succ_out = mf_FS(4);
                
                m_cw_FS = abs(hf_FS)/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_FS];
                
                
            case 'ES'
                m_ES_in = m;
                c_ES_in = c;
                
                T_ES_in = 30;
                T_ES_out = 40;
                
                stats_ES_in = [v_ES,T_ES_in,T_ES_out];                
                
                [m_ES_l_out, c_ES_l_out, m_ES_v_out, c_ES_v_out, stats_ES_out, mf_ES, hf_ES, design_ES] = evaporation_model_succ(m_ES_in, c_ES_in, stats_ES_in, Aspen.CF);
                
                m = m_ES_l_out;
                c = c_ES_l_out;
                                
                KPI.FCI = KPI.FCI + design_ES(2);
                
                m_wwt = m_wwt + m_ES_v_out;
                m_lpsteam = m_lpsteam + hf_ES(1)/h_lp;
                
                m_cw_ES = (abs(hf_ES(2)) + abs(hf_ES(3)))/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_ES];  
                
                
            case 'CS1'
                m_CS1_in = m;
                c_CS1_in = c;
                
                Ti_CS1 = 40;
                TC_CS1 = 15;
                FAS_CS1 = 0;
                rho_liquid_CS1 = 1050; % kg/m3
                
                stats_CS1 = [t_CS1, Ti_CS1, TC_CS1, FAS_CS1, FC_CS1, rho_liquid_CS1];
                
                [m_CS1_out, c_CS1_out, stats_CS1_out, mf_CS1, hf_CS1, design_CS1] = crystallization_model_succ(m_CS1_in, c_CS1_in, stats_CS1);
                
                m = m_CS1_out;
                c = c_CS1_out;
                Tf_CS1 = stats_CS1_out(1);
                
                Mass.Succinic_Acid = Mass.Succinic_Acid + mf_CS1(1);
                KPI.FCI = KPI.FCI + design_CS1(2);
                
                m_wwt = m_wwt + m_CS1_out;
                
                m_cw_CS1 = abs(hf_CS1)/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_CS1];
                
                
            case 'CS2'
                m_wwt = m_wwt - m_CS1_out;
                
                m_CS2_in = m;
                c_CS2_in = c;
                
                Ti_CS2 = Tf_CS1;
                TC_CS2 = 5;
                FAS_CS2 = 0;
                rho_liquid_CS2 = 1050; % kg/m3
                
                stats_CS2 = [t_CS2, Ti_CS2, TC_CS2, FAS_CS2, FC_CS2, rho_liquid_CS2];
                
                [m_CS2_out, c_CS2_out, stats_CS2_out, mf_CS2, hf_CS2, design_CS2] = crystallization_model_succ(m_CS2_in, c_CS2_in, stats_CS2);
                
                m = m_CS2_out;
                c = c_CS2_out;
                
                Mass.Succinic_Acid = Mass.Succinic_Acid + mf_CS2(1);
                KPI.FCI = KPI.FCI + design_CS2(2);
                
                m_wwt = m_wwt + m_CS2_out;
                
                m_cw_CS2 = abs(hf_CS2)/(cp_water * 5);
                m_ccooling = m_ccooling + m_cw_CS2;                
                
                
            case 'LP'
                m_LP_in = m_EH_s_out;
                c_LP_in = c_EH_s_out;
                
                dT_LP = 80;
                
                stats_LP_in = [t_LP, Tmax_LP];
                
                [m_LP_out, c_LP_out, mf_LP, hf_LP, design_LP] = pyrolysis_model(m_LP_in, c_LP_in, stats_LP_in);
                
                m = m_LP_out;
                c = c_LP_out;
                
                m_lignin = m_lignin - m_EH_s_out + m_LP_out * sum(c_LP_out(1:13))/100 + m_LP_out * sum(c_LP_out(51:53));
                
                m_fg = m_fg + hf_LP/h_fg;
                                
                KPI.FCI = KPI.FCI + design_LP(2);
                
                
            case 'LH'
                m_LH_in = m;
                c_LH_in = c;
                
                eps_bed_LH = 0.4;
                
                stats_LH_in = [T_LH, length_LH, diameter_LH, eps_bed_LH, Tmax_LP];
                
                [m_LH_out, c_LH_out, mf_LH, hf_LH, design_LH] = hydrotreatment_model(m_LH_in, c_LH_in, stats_LH_in);
                
                m = m_LH_out;
                c = c_LH_out;                
                                
                KPI.FCI = KPI.FCI + design_LH(2);
                m_h2 = m_h2 + mf_LH;
                m_ca = m_ca + hf_LH/h_ca;
                
            case 'LF'
                m_LF_in = m;
                c_LF_in = c;
                
                T_in_LF = 450;
                p_in_LF = 65;
                
                stats_LF_in = [T_in_LF, p_in_LF, p_f1_LF, p_f2_LF];
                
                [m_LF_l, c_LF_l, m_LF_v, c_LF_v, m_LF_p, c_LF_p, mf_LF, hf_LF, design_LF] = fractionation_model(m_LF_in, c_LF_in, stats_LF_in, Aspen.LF);
                
                Mass.Kerosene = m_LF_l;
                Mass.Flue_Gas = m_LF_v;                
                KPI.FCI = KPI.FCI + design_LF(3);
                
                m_wwt = m_wwt + m_LF_p;
                
                m_cw_LF = abs(hf_LF)/(cp_water * 5);
                m_cooling = [m_cooling, m_cw_LF];

            case 'blank'
                
        end    
    end
    
    
%% Combustion & energy production
m_wwt = m_wwt + 0.4 * m_cell_biomass; % solid/liquid separation
m_cell_biomass = 0.6 * m_cell_biomass;

Mass.WWT = m_wwt;

[M_steam, P_el, M_freshwater, m_ashes, m_brine] = combustion_energy_production(m_cell_biomass, m_lignin, m_LF_v, m_wwt);
Mass.Ashes = m_ashes;
Mass.Brine = m_brine;

%% Auxiliary equipment costs
m_cooling = max(m_cooling);
Mass.Cooling = m_cooling;

FCI_auxiliary = costing_auxiliary_equipment(m_feedstock, Mass.Xylitol, Mass.Succinic_Acid, Mass.Kerosene, m_acid, m_base, m_titr, m_nitro, m_antisolvent, m_wwt, M_steam, Mass.Cooling);

KPI.FCI = KPI.FCI + FCI_auxiliary;

%% Total Costs of Installation (CAPEX)
KPI.TCI = total_production_costs(KPI.FCI);

%% OPEX
m_cooling_makeup = max(m_cooling) * 0.0122; % according to NREL report
m_ccooling_makeup = m_ccooling * 0.01; % according to cooling makeup

Mass.Cooling_Makeup = m_cooling_makeup;
Mass.Ccooling_Makeup = m_ccooling_makeup;

m_net_steam = m_lpsteam + m_mpsteam - M_steam;
m_net_water = m_water - M_freshwater;
P_el_net = 28 * m_feedstock/772575300 - P_el;
m_fg_net = m_fg - m_LF_v;

Mass.Steam_Net = m_net_steam;
Mass.Water_Net = m_net_water;
Mass.El_Net = P_el_net;
Mass.Flue_Gas_Net = m_fg_net;

[C_VOC, C_FOC, C_sales] = costing_utilities(m_feedstock, m_acid, m_base, m_nitro, m_titr, m_antisolvent, m_enzyme, m_co2_succinic_acid, m_h2, m_net_water, m_net_steam, m_cooling_makeup, m_ccooling_makeup, m_fg_net, P_el_net, Mass.Xylitol, Mass.Succinic_Acid, Mass.Kerosene, m_brine, m_acid);

KPI.TPC = C_VOC + C_FOC;
KPI.Sales = C_sales;

%% Key Performance Indicators (KPI)
[ROI, PBP, NPV, DCFR, MSEP] = key_performance_indicators(KPI.TCI, KPI.TPC, KPI.Sales, KPI.FCI, Mass.Xylitol, Mass.Succinic_Acid, Mass.Kerosene);

KPI.ROI = ROI;
KPI.PBP = PBP;
KPI.NPV = NPV;
KPI.DCFR = DCFR;
KPI.MSEP = MSEP;

end

%% Combustion & Energy Production
function [M_steam, P_el, M_freshwater, m_ashes, m_brine] = combustion_energy_production(m_cell_biomass, m_lignin, m_flue_gas, m_wwt)

m_cell_biomass = m_cell_biomass  / 300 / 24; % Vamvuka et al., 2019 (Frontiers in Energy Research - Bioenergy and Biofuels)
m_lignin = m_lignin / 300 / 24;

m_flue_gas = m_flue_gas / 300 / 24;
m_wwt = m_wwt / 300 / 24;

m_ashes = 0.2 * m_cell_biomass + 0.1 * m_lignin;
m_lignin = 0.9 * m_lignin;
m_cell_biomass = 0.8 * m_cell_biomass;


% Reference values
P_0 = 5464; % [MW]
M_steam_0 = 239000; % kg/h
P_el_0 = 42; % [MW]
M_fresh_0 = 376324; % kg/h
M_wwt_0 = 393100; % kg/h
M_biogas_0 = 21860; % kg/h
M_sludge_0 = 9758; % kg/h

% masses
m_solids = m_cell_biomass + m_lignin; % solids from cell biomass and lignin (+cellulose & hemicellulose) rests

m_biogas = M_biogas_0/M_wwt_0 * m_wwt; % scaled biogas from wwt
m_sludge = M_sludge_0/M_wwt_0 * m_wwt; % scaled sludge from wwt

% heating values
H0_flue_gas = 50; % MJ/kg
H0_biogas =  40; % MJ/kg
H0_solids = 20; % MJ/kg
H0_sludge = 10; % MJ/kg

% power generation by combustion
P_flue_gas = m_flue_gas * H0_flue_gas / 3600; % MW
P_biogas = m_biogas * H0_biogas / 3600; % MW
P_solids = m_solids * H0_solids / 3600; % MW
P_sludge = m_sludge * H0_sludge / 3600; % MW

P = P_flue_gas + P_biogas + P_solids + P_sludge;

% created heat steam & electric power
M_steam = M_steam_0 * P / P_0;
P_el = P_el_0 * P / P_0;
M_freshwater = M_fresh_0 * m_wwt / M_wwt_0;

M_steam = M_steam * 300 * 24; % kg/y
P_el = P_el;                   % MW
M_freshwater = M_freshwater * 300 * 24; % kg/y

% brine leaving the wwt
m_brine = m_wwt * 300 * 24 - M_freshwater;
m_ashes = m_ashes * 300 * 24;

end


%% Costing Utilities % Products
function [C_utilities, C_FOC, C_sales] = costing_utilities(m_feedstock, m_acid, m_base, m_nitro, m_titr, m_antisolvent, m_enzyme, m_co2, m_h2, m_net_water, m_net_steam, m_cooling_makeup, m_ccooling_makeup, m_fg_net, P_el_net, m_xylitol, m_succinic_acid, m_kerosene, m_brine, m_ashes)
% Prices
p_feedstock = 117.86; % $/t
p_sulfuric_acid = 93; % $/t
p_sodium_hydroxide = 134.43; % $/t
p_enzyme = 2085; % $/t
p_ammonia = 685; % $/t
p_potassium_phosphate = 1268.41; % $/t
p_ethanol = 517; % $/t
p_carbon_dioxide = 50; % $/t
p_hydrogen = 1400; % $/t


p_freshwater = 0.53; % $/t (McGrawHill)
p_cooling = 0.23; % $/t (NREL)
p_ccooling = 3 * p_cooling;
% p_LPsteam = 4.4; % $/t
p_MPsteam = 29.59; % $/t (see excel)
% p_HPsteam = 4.4; % $/t
p_electricity = 0.06; % $/kWh (see excel)
p_fuel_gas = 0.7459; % $/t (see excel)

p_brine = 0.53; % $/t (McGrawHill)
p_ashes = 28.86; % $/t (NREL)

p_xylitol = 6350; % $/t
p_succinic_acid = 2860; % $/t
p_kerosene = 1.3*785.54; % $/t

% Costs ($/y)
C_feedstock = p_feedstock * m_feedstock / 1000;
C_acid = p_sulfuric_acid * m_acid / 1000;
C_base = p_sodium_hydroxide * m_base / 1000;
C_nitro = p_ammonia * m_nitro / 1000;
C_titr = p_potassium_phosphate * m_titr / 1000;
C_antisolvent = p_ethanol * m_antisolvent / 1000;
C_enzyme = p_enzyme * m_enzyme / 1000;
C_carbon_dioxide = p_carbon_dioxide * m_co2 / 1000;
C_hydrogen = p_hydrogen * m_h2 / 1000;

C_water = p_freshwater * abs(m_net_water) / 1000;
C_steam = p_MPsteam * abs(m_net_steam) / 1000;
C_el = p_electricity * abs(P_el_net) * 3600 * 24 * 300 /3.6; % in kWh
C_fg = p_fuel_gas * abs(m_fg_net) / 1000;

C_cooling = p_cooling * m_cooling_makeup / 1000;
C_ccooling = p_ccooling * m_ccooling_makeup / 1000;

C_brine = p_brine * m_brine / 1000;
C_ashes = p_ashes * m_ashes / 1000;

% Fixed Operational expenses (salary etc.)
m_0 = 600e6;
C_FOC_00 = 10.66e6;
n_FOC = 10; % ten years difference
C_FOC_0 = C_FOC_00 * (1+0.01)^n_FOC;
C_FOC = C_FOC_0 * m_feedstock/m_0;

% Sales
C_xylitol = p_xylitol * m_xylitol / 1000;
C_succinic_acid = p_succinic_acid * m_succinic_acid / 1000;
C_kerosene = p_kerosene * m_kerosene / 1000;


C_utilities = C_feedstock + C_acid + C_base + C_nitro + C_titr + C_antisolvent + C_enzyme + C_carbon_dioxide + C_hydrogen + C_water + C_steam + C_el + C_cooling + C_ccooling + C_brine + C_ashes;
C_sales = C_xylitol + C_succinic_acid + C_kerosene;

end

%% Costing Auxiliary Equipment
function FCI = costing_auxiliary_equipment(m_feed, m_xyo, m_sac, m_ker, m_acid, m_base, m_titr, m_nitro, m_as, m_wwt, M_steam, m_cooling)

%% Feedstock
CP_feed = m_feed / 300 / 24; % kg/h

% Capacity NREL Plant
CP0_feed = 94697; % kg/h

% Fixed capital investment for unit
FCI00_feed = 1414478; % $(2010)
n_feed = 10; % ten years difference 2021 - 2011
FCI0_feed = FCI00_feed * (1+0.01)^n_feed;

% Plant Capacity ration
x_feed = 0.6; % extrapolation factor, based on other reaction systems

FCI_feed = FCI0_feed * (CP_feed/CP0_feed)^x_feed;

%% Material Storage

m_store = [m_xyo, m_sac, m_ker, m_acid, m_base, m_titr, m_nitro, m_as];
CP_store = m_store ./ 300 ./ 24; % kg/h

% Capacity own plant
CP0_xyo = 10; % kg/h
CP0_suc = 10; % kg/h
CP0_ker = 473; % kg/h

CP0_acid = 1981; % kg/h - according to NREL, storage for 7 days
CP0_base = 1981; % kg/h - according to NREL, storage for 7 days, same as acid
CP0_titr = 1981; % kg/h - according to NREL, storage for 7 days, same as acid
CP0_nitro = 1171; % kg/h - according to NREL, storage for 7 days
CP0_as = 22681; % kg/h

CP0_store = [CP0_xyo, CP0_suc, CP0_ker, CP0_acid, CP0_base, CP0_titr, CP0_nitro, CP0_as];

% Fixed capital investment for unit (storage + pump (L)/dryer (S))
FCI00_xyo = 27276+9473; % $(2011)
FCI00_suc = 27276+9473; % $(2011)
FCI00_ker = 200000 + 3000; % $(2011)

FCI00_acid = 96000 + 7493; % $(2011)
FCI00_base = 96000 + 7493; % $(2011)
FCI00_titr = 96000 + 7493; % $(2011)
FCI00_nitro = 196000; % $(2011)
FCI00_as = 1340000 + 9200; % $(2011)

FCI00_store = [FCI00_xyo, FCI00_suc, FCI00_ker, FCI00_acid, FCI00_base, FCI00_titr, FCI00_nitro, FCI00_as];

n_store = 10; % ten years difference 2021 - 2011
FCI0_store = FCI00_store .* (1+0.01)^n_store;

% Plant Capacity ration
x_store = 0.7; % extrapolation factor, based on the report

FCI_store = FCI0_store .* (CP_store./CP0_store).^x_store;

FCI_store = sum(FCI_store);

%% Wastewater Treatment
% Capacity own plant
CP_wwt = m_wwt / 300 / 24; % kg/h

% Capacity NREL Plant
CP0_wwt = 393100; % kg/h

% Fixed capital investment for unit
FCI00_wwt = 51654964; % $(2010)
n_wwt = 10; % ten years difference 2021 - 2011
FCI0_wwt = FCI00_wwt * (1+0.01)^n_wwt;

% Plant Capacity ratio
x_wwt = 1.05; % extrapolation factor, based on the report

FCI_wwt = FCI0_wwt * (CP_wwt/CP0_wwt)^x_wwt;

%% Combustion and Energy Provision
% Capacity own plant
CP_steam = M_steam / 300 / 24;

% Capacity NREL plant
CP0_steam = 239000; % kg/h

% Fixed capital investment for unit
FCI00_steam = 38111118; % $ (2010)
n_steam = 10; % ten years difference 2021 - 2011
FCI0_steam = FCI00_steam * (1+0.01)^n_steam;

% Plant Capacity ratio
x_steam = 0.6;

FCI_steam = FCI0_steam * (CP_steam/CP0_steam)^x_steam;

%% Utilities
% Max capacity own plant (based on cooling, major cost part in utilities)
CP_cooling = m_cooling / 300 / 24;

% Capacity NREL plant
CP0_cooling = 10037820;

% Fixed capital investment for unit
FCI00_cooling = 4114396;
n_cooling = 10; % ten years difference 2021 - 2011
FCI0_cooling = FCI00_cooling * (1+0.01)^n_cooling;

% Plant Capacity ration
x_cooling = 0.6;

FCI_cooling = FCI0_cooling * (CP_cooling/CP0_cooling)^x_cooling;
FCI_utilities = FCI_cooling;

%% Sum
FCI = FCI_feed + FCI_store + FCI_wwt + FCI_steam + FCI_utilities;

end

%% Total Production Costs
function TCI = total_production_costs(FCI)
% Total direct costs
TDC = FCI * 1.0788; % 7.88% according to NREL report (basing it on inventory levels)

% Total indirect costs
TIC = TDC * 0.6; % 60% of TDC according to NREL report

% Fixed capital investment
CI = TDC + TIC;

% Total capital investment
TCI = CI * 1.0547; % 5.47% of CI according to NREL report

end

%% Key Performance Indicators (KPI)
function [ROI, PBP, NPV, DCFR, MSEP] = key_performance_indicators(TCI, TPC, Sales, FCI, m_xyo, m_suc, m_ker)
time = 30; % plant life time in years
marr = 0.10; % minimum acceptable rate of return
building_period = 2; % assuming two years building period
MACRS_5 = [0.2, 0.32, 0.192, 0.1152, 0.1152, 0.0576]; % MACRS scheme for 5 years depreciation
MACRS = zeros(time,1); MACRS(2:7) = MACRS_5;
phi = 0.35; % income tax rate

% Return on Investment - ROI
ROI = (Sales - TPC) / TCI * 100; % in percent

% Payback Period - PBP
PBP = FCI / ((Sales - TPC)*(1-phi) + phi * mean(MACRS)); % assuming averaged depreciation

% Net Present Value - NPV
byears = linspace(-building_period, time, time+building_period + 1);
years = linspace(0,time, time+1);

PWF_cf = zeros(1,length(years)); % present worth factor of cash flow per year
PWF_v = zeros(1,length(byears)); % present worth factor of investment per year

for i=1:length(years)
    PWF_cf(i) = (1+marr)^(-years(i));
end

for i=1:length(byears)
    PWF_v(i) = (1+marr)^(-byears(i));
end

MACRS = zeros(1,length(years));
MACRS(1,2:7) = MACRS_5;
TCI_years = zeros(1,length(byears));
TCI_years(1:3) = [0.6*TCI, 0.32*TCI, 0.08*TCI];
rec = zeros(1,length(years)); rec(end) = 0.15*TCI; % recovery

NPV = sum(PWF_cf.*((Sales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum(PWF_v.*TCI_years);

% Discounted Cash Flow of Return - DCFR
fun = @(DCFR) sum((1+DCFR).^(-years) .* ((Sales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum((1+DCFR).^(-byears) .*TCI_years);
x0 = 0;

options = optimoptions('fsolve','Display','off');
DCFR = fsolve(fun,x0,options);

% Minimum Selling Price of Products
fun2 = @(MinSales) sum((1+marr).^(-years) .* ((MinSales - TPC - MACRS.*FCI).*(1-phi) + rec + MACRS.*FCI)) - sum((1+marr).^(-byears) .*TCI_years);
x0 = 1e8;

options = optimoptions('fsolve','Display','off');
MinSales = fsolve(fun2,x0,options);

p_succinic_acid = 2860; % $/t
p_kerosene = 1.3*785.54; % $/t


MSEP = (MinSales - m_suc/1000*p_succinic_acid - m_ker/1000*p_kerosene)/(m_xyo/1000); % minimum selling price xylitol


end