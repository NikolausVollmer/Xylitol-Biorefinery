clear
close all
clc

addpath("../sampling")
addpath("../models")

% rng(42,'twister')

[T, configIDs] = nk_ctable;

cIDs     = [1,3,4,9,11,12,17,19,20,25,27,28];

for cID = cIDs

configID = configIDs{cID}; 
space    = nk_designSpace(configID); show(space);
N        = 1000;

%% Sampling with boundary points
red = reduced_space(cID);

% Sampling without boundary points
X        = nk_sampleLHS(N,space.LowerBounds(red),space.UpperBounds(red));

%% Simulations
mcsfolder = sprintf('c%d_mcsims',cID); % name of the folder where for iters are stored
if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end
 
% perform mcsims
for i=1:N
    try
        % Start Aspen
        if mod(N+1-i,100) == 0
            HF = StartAspen("HF");
            CF = StartAspen("CF");
            LF = StartAspen("LF");

            Aspen = struct("HF", HF, "CF", CF, "LF", LF);
        end
        
        fprintf('Configuration ID %d, started run %d. ',cID,i);
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        if exist(filename,'file')==2
            continue;
        end

        % reduced input space
        xr = X(i,:);
        x = space.SetPoints;
        x(red) = xr;
        
        % run simulation
        [KPI, Mass] = nk_runfs(x,space,configID,Aspen)

        m=matfile(filename,'writable',true); m.KPI=KPI; m.Mass=Mass;
        fprintf('Finished a successful run.\n')

        % close Aspen
        if mod(i,100) == 0
            CloseAspen(CF);
            CloseAspen(HF);
            CloseAspen(LF);
            clear Aspen CF HF LF
        end
        
        
    catch ME
        fprintf('Hit an error.\n')
        rethrow(ME)
    end
end


% collect completed sims
for i=1:N
    try
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        m=matfile(filename,'writable',true);
        D(i).KPI  = m.KPI;
        D(i).Mass = m.Mass;
    catch ME
        D(i).KPI  = NaN;
        D(i).Mass = NaN;
        %rethrow(ME)
    end
end


% Put all KPIs and Masses into a table T
S = struct;
fnames = fields(D(1).KPI);
gnames = fields(D(1).Mass);

for i=1:numel(D)
    for j=1:numel(fnames)
        try
            S(i).(fnames{j}) = D(i).KPI.(fnames{j});
        catch
            S(i).(fnames{j}) = NaN;
        end
    end
    
    for j=1:numel(gnames)
        try
            S(i).(gnames{j}) = D(i).Mass.(gnames{j});
        catch
            S(i).(gnames{j}) = NaN;
        end
    end
end

To = struct2table(S) % convert to a table        
Ti = array2table(X,'VariableNames',space.ParNames(red));

writetable(Ti,sprintf("C%di_%d.csv",cID,N))
writetable(To,sprintf("C%do_%d.csv",cID,N))

% Save run
save(sprintf("c%d_MCS",cID))

end

function red = reduced_space(cID)

red_cID1 = [9,21,25,27,29];
red_cID2 = [7,15,18,20,22];
red_cID3 = [8,19,24,25,27];
red_cID4 = [6,13,17,18,20];

red_cID9 = [9,21,26,27,28];
red_cID10 = [7,15,19,20,21];
red_cID11 = [8,19,23,25,26];
red_cID12 = [6,13,16,18,19];

red_cID17 = [8,19,23,25,27];
red_cID18 = [6,13,16,18,20];
red_cID19 = [7,17,22,23,25];
red_cID20 = [5,11,15,16,18];

red_cID25 = [8,19,24,25,26];
red_cID26 = [6,13,17,18,19];
red_cID27 = [7,17,22,23,24];
red_cID28 = [5,11,14,16,17];

red_0 = [0,0,0,0,0];

red_cID = [red_cID1;red_cID2;red_cID3;red_cID4;
           red_0;red_0;red_0;red_0;
           red_cID9;red_cID10;red_cID11;red_cID12;
           red_0;red_0;red_0;red_0;
           red_cID17;red_cID18;red_cID19;red_cID20;
           red_0;red_0;red_0;red_0;
           red_cID25;red_cID26;red_cID27;red_cID28;
           red_0;red_0;red_0;red_0];


red = red_cID(cID,:);

end

