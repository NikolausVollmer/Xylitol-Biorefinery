clear; clc;

cIDs = 128;
N = 100;

for cID = 5:cIDs

    mcsfolder = sprintf('c%d_mcsims',cID); % name of the folder where for iters are stored

    for i = 1:N
        try
            filename = fullfile(mcsfolder, sprintf('row%d',i));
            m=matfile(filename,'writable',true);
            D(i).KPI = m.KPI;
        catch ME
            D(i).KPI  = NaN;
        end
    end

    S=struct;
    fnames=fields(D(1).KPI);
    for i=1:numel(D)
        for j=1:numel(fnames)
            try
                S(i).(fnames{j}) = D(i).KPI.(fnames{j});
            catch
                S(i).(fnames{j}) = NaN;
            end
        end
    end
    To = struct2table(S) % convert to a table
    cID

end
