clear
clc

addpath("../sampling")
addpath("../models")

rng(42,'twister')

[T, configIDs] = nk_ctable; 
cID = 8; 
configID = configIDs{cID}; 
space    = nk_designSpace(configID); show(space);
M        = 5;
N        = 500;

red = [1,2,3,4,5,6,7,8];
for d = 1:M
    %% only for the bounds
    Xlow = ff2n(length(red))
    Xup = 1- Xlow
    Xlow = Xlow.* space.LowerBounds(red)
    Xup = Xup .* space.UpperBounds(red)
    X1 = Xlow + Xup

    X2        = nk_sampleLHS(N - length(X1),space.LowerBounds(red),space.UpperBounds(red));
    X         = vertcat(X1,X2)
    % X        = nk_sampleLHS(N,space.LowerBounds(red),space.UpperBounds(red));
    mcsfolder = sprintf('c%d_training',cID); % name of the folder where for iters are stored
    if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end


    %Start Aspen
    % Aspen = actxserver('Apwn.Document.37.0'); %35.0 = V9.0; 36.0 = V10.0; 37.0 = V11.0
    % [stat,mess] = fileattrib; % get attributes of folder (Necessary to establish the location of the simulation)
    % % mess.Name = 'C:\Users\nikov\Dropbox\Niko Resul\models\evaporation_xylitol';
    % mess.Name = 'M:\4 Modelling\1 Unit Operations\4 Evaporation\2 Evaporator for use';
    % Simulation_Name = 'evap_cont'; % Aspen Plus Simulation Name
    % Aspen.invoke('InitFromArchive2',[mess.Name '\' Simulation_Name '.bkp']);
    % Aspen.Visible = 0; % 1 = Aspen is Visible; 0 = Aspen is open but not visible
    % Aspen.SuppressDialogs = 1; % 1 = Suppress windows dialogs; 0 = allow windows dialogs;
    % Aspen.Engine.Run2(1); % Run the simulation
    Aspen = 0;


    % perform mcsims
    for i=1:N
        try
            filename = fullfile(mcsfolder, sprintf('trun%d_row%d',d,i));
            if exist(filename,'file')==2, continue; end

            xr = X(i,:);
            x = mean([space.LowerBounds;space.UpperBounds]);
            x(red) = xr

            KPI = nk_runfs(x,space,configID,Aspen);

            m=matfile(filename,'writable',true); m.KPI=KPI; 
            fprintf('Finished a successful run.\n')
        catch ME
            fprintf('Hit an error.\n')
            %rethrow(ME)
        end
    end

    save(sprintf("run%d_c%d_MCS",j,cID))

    % collect completed sims
    for i=1:N
        try
            filename = fullfile(mcsfolder, sprintf('trun%d_row%d',d,i));
            m=matfile(filename,'writable',true);
            D(i).KPI = m.KPI;
        catch ME
            D(i).KPI  = NaN;
            %rethrow(ME)
        end
    end


    % Put all KPIs into a table T
    S=struct;
    fnames=fields(D(1).KPI);
    for i=1:numel(D)
        for j=1:numel(fnames)
            try
                S(i).(fnames{j}) = D(i).KPI.(fnames{j});
            catch
                S(i).(fnames{j}) = NaN;
            end
        end
    end
    To = struct2table(S) % convert to a table        
    Ti = array2table(X,'VariableNames',space.ParNames(red));

    writetable(Ti,sprintf("run%d_C%di.csv",d,cID))
    writetable(To,sprintf("run%d_C%do.csv",d,cID))
end