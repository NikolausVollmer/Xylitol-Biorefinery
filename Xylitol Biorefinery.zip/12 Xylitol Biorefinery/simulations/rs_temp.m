%% Using MultiStart
% https://se.mathworks.com/help/gads/how-globalsearch-and-multistart-work.html

x0       = (space.LowerBounds+space.UpperBounds)/2;
lbs      = space.LowerBounds;
ubs      = space.UpperBounds;
fun      = @(x) -objGPR(x); % put minus for maximize 
cons     = @(x) deal([con1GPR(x) con2GPR(x)],[]);
opts     = optimoptions('fmincon','Display','None','Algorithm','sqp');
problem  = createOptimProblem('fmincon','x0',x0,'lb',lbs,'ub',ubs,...
          'objective',fun,'nonlcon',cons,'options',opts);

ms       = MultiStart('UseParallel',true,'Display','none'); 
[x,fval] = run(ms,problem,50);

save MSresults

%% Using KNITRO
addpath('C:\Program Files\Artelys\Knitro 11.1.0\knitromatlab');

fun  = @(x)100*(x(2)-x(1)^2)^2 + (1-x(1))^2;  
cons = @(x) deal([(x(1)-1/3)^2 + (x(2)-1/3)^2 - (1/3)^2],[]);
lbs = [0,0.2];
ubs = [0.5,0.8];  
x0 = [1/4,1/4]; 

opts = optimset('Algorithm', 'interior-point', 'Display','iter','UseParallel', true, 'MaxFunEvals', 100); extendedFeatures=[]; KnitroOptions=[];
[x,fval,exitflag,output,lambda,grad,hessian] = knitromatlab(fun,x0,[],[],[],[],lbs,ubs,cons, ...
                                                            extendedFeatures,opts,KnitroOptions);

function f = myObjective(x)
    % optimization objective
    
    
    
    f = [];
end

function [c,ceq] = myConstraints(x)
    % optimization constraints
    
    
    
    c   = [];
    ceq = [];
end







