clear
close all
clc

addpath("../sampling")
addpath("../models")

% rng(42,'twister')

[T, configIDs] = nk_ctable;

cID      = 2; % configuration ID
configID = configIDs{cID}; 
space    = nk_designSpace(configID); show(space);

N        = 1000; % MC sampling number

%% Input space
% General input
f_range  = [150000000,600000000];
YP       = zeros(N,1);
red      = [7,15,19,20,22]; % modified reduced input space for cID 2
lb       = space.LowerBounds(red);
ub       = space.UpperBounds(red);

% Integrate feedstock mass
lb       = [lb, f_range(1)];
ub       = [ub, f_range(2)];

X        = nk_sampleLHS(N,lb,ub);

% Separate feedstock mass
MF       = X(:,end);
X        = X(:,[1:length(red)]);

%% Simulations
mcsfolder = sprintf('c%d_vcosims',cID); % name of the folder where for iters are stored
if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end
 
% perform mcsims
for i=1:N
    try
        % Start Aspen
        if mod(N+1-i,100) == 0      
            HF = StartAspen("HF");
            CF = StartAspen("CF");
            LF = StartAspen("LF");

            Aspen = struct("HF", HF, "CF", CF, "LF", LF);
        end
        
        fprintf('Configuration ID %d, started run %d. ',cID,i);
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        if exist(filename,'file')==2
            continue;
        end

        % full input space
        x  = X(i,:);
        mf = MF(i,:);
        yp = YP(i,:);
        
        [KPI, Mass] = nk_runfs_vco(x,space,configID,Aspen,mf,yp)

        m=matfile(filename,'writable',true); m.KPI=KPI; m.Mass = Mass;
        fprintf('Finished a successful run.\n')
        
        % close Aspen
        if mod(i,100) == 0            
            CloseAspen(CF);
            CloseAspen(HF);
            CloseAspen(LF);
            
            clear Aspen CF HF LF
        end
        
        
    catch ME
        fprintf('Hit an error.\n')
        rethrow(ME)
    end
end

% collect completed sims
for i=1:N
    try
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        m=matfile(filename,'writable',true);
        D(i).KPI  = m.KPI;
        D(i).Mass = m.Mass;
    catch ME
        D(i).KPI  = NaN;
        D(i).Mass = Mass;
        %rethrow(ME)
    end
end


% Put all KPIs and Masses into a table T
S = struct;
fnames = fields(D(1).KPI);
gnames = fields(D(1).Mass);

for i=1:numel(D)
    for j=1:numel(fnames)
        try
            S(i).(fnames{j}) = D(i).KPI.(fnames{j});
        catch
            S(i).(fnames{j}) = NaN;
        end
    end
    
    for j=1:numel(gnames)
        try
            S(i).(gnames{j}) = D(i).Mass.(gnames{j});
        catch
            S(i).(gnames{j}) = NaN;
        end
    end
end

To = struct2table(S) % convert to a table        
Ti = array2table(X,'VariableNames',space.ParNames);

writetable(Ti,sprintf("C%di_%d_VCO.csv",cID,N))
writetable(To,sprintf("C%do_%d_VCO.csv",cID,N))

% Save run
save(sprintf("c%d_VCO",cID))
