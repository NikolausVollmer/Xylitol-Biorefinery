function uMap = nk_unitMap(varargin)
    % Storing Unit data in UnitClass and InputSpace objects 
    % By Niko 21/08/2020
    
    % Input space consists of ("Variable Names", "Lower Bounds", "Upper Bounds", "Set Points")
    
    % Biomass Pretreatment
    PT                     = UnitClass();
    PT.KEY                 = 'PT';
    PT.FullName            = 'Biomass Pretreatment';
    PT.DesignSpace         = InputSpace({'T_PT','t_PT','acid'},[173, 18, 0.5],[195, 30, 2.0],[195, 18, 1.25]);

    % Upconcentration Hemicellulose
    UH                     = UnitClass();
    UH.KEY                 = 'UH';
    UH.FullName            = 'Upconcentration Hemicellulose';
    UH.DesignSpace         = InputSpace({'v_UH'},[0.4],[0.6],[0.5]);
    
    % Fermentation Xylitol
    FX                     = UnitClass();
    FX.KEY                 = 'FX';
    FX.FullName            = 'Fermentation Xylitol';
%     FX.DesignSpace         = InputSpace({'t_FX','Vfrac_FX','tfstart_FX'},[12, 0.25, 0],[48, 0.4, 0.33],[24, 0.33, 0.25]);
    FX.DesignSpace         = InputSpace({'t_FX','Vfrac_FX','tfstart_FX'},[12, 0.25, 0],[72, 0.5, 0.33],[24, 0.33, 0.25]);
    
    % Evaporation Xylitol
    EX                     = UnitClass();
    EX.KEY                 = 'EX';
    EX.FullName            = 'Evaporation Xylitol';
%     EX.DesignSpace         = InputSpace({'v_EX'},[0.97],[0.995],[0.99]);
    EX.DesignSpace         = InputSpace({'v_EX'},[0.97],[0.998],[0.99]);
    
    % Crystallization Xylitol 1
    CX1                     = UnitClass();
    CX1.KEY                 = 'CX1';
    CX1.FullName            = 'Crystallization Xylitol 1';
    CX1.DesignSpace         = InputSpace({'t_CX1','FC_CX1'},[2, 0.1],[12, 0.3],[12, 0.25]);
    
    % Crystallization Xylitol 2
    CX2                     = UnitClass();
    CX2.KEY                 = 'CX2';
    CX2.FullName            = 'Crystallization Xylitol 2';
    CX2.DesignSpace         = InputSpace({'t_CX2','FAS_CX2'},[2, 0.01],[12, 0.2],[12, 0.1]);
    
    % Enzymatic Hydrolysis
    EH                     = UnitClass();
    EH.KEY                 = 'EH';
    EH.FullName            = 'Enzymatic Hydrolysis';
    EH.DesignSpace         = InputSpace({'t_EH'},[96],[168],[120]);
    
    % Upconcentration Cellulose
    UC                     = UnitClass();
    UC.KEY                 = 'UC';
    UC.FullName            = 'Upconcentration Cellulose';
    UC.DesignSpace         = InputSpace({'v_UC'},[0.2],[0.3],[0.25]);
    
    % Fermentation Succinic Acid
    FS                     = UnitClass();
    FS.KEY                 = 'FS';
    FS.FullName            = 'Fermentation Succinic Acid';
    FS.DesignSpace         = InputSpace({'t_FS','Vfrac_FS','tfstart_FS',},[12, 0.25, 0],[48, 0.4, 0.2],[36, 0.33, 0.1]);
    
    % Evaporation Succinic Acid
    ES                     = UnitClass();
    ES.KEY                 = 'ES';
    ES.FullName            = 'Evaporation Succinic Acid';
    ES.DesignSpace         = InputSpace({'v_ES'},[0.75],[0.85],[0.85]);
    
    % Crystallization Succinic Acid 1
    CS1                     = UnitClass();
    CS1.KEY                 = 'CS1';
    CS1.FullName            = 'Crystallization Succinic Acid 1';
    CS1.DesignSpace         = InputSpace({'t_CS1','FC_CS1'},[2, 100],[12, 300],[12, 250]);
    
    % Crystallization Succinic Acid 2
    CS2                     = UnitClass();
    CS2.KEY                 = 'CS2';
    CS2.FullName            = 'Crystallization Succinic Acid 2';
    CS2.DesignSpace         = InputSpace({'t_CS2','FC_CS2'},[2, 100],[12, 300],[12, 250]);
    
    % Lignin Pyrolysis
    LP                     = UnitClass();
    LP.KEY                 = 'LP';
    LP.FullName            = 'Lignin Pyrolysis';
    LP.DesignSpace         = InputSpace({'t_LP','Tmax_LP'},[30, 425],[300, 475],[90, 450]);
    
    % Lignin Hydrotreatment
    LH                     = UnitClass();
    LH.KEY                 = 'LH';
    LH.FullName            = 'Lignin Hydrotreatment';
    LH.DesignSpace         = InputSpace({'T_LH','length_LH','diameter_LH'},[425, 10, 1],[475, 50, 5],[450, 25, 2.5]);
    
    % Lignin Fractionation
    LF                     = UnitClass();
    LF.KEY                 = 'LF';
    LF.FullName            = 'Lignin Fractionation';
    LF.DesignSpace         = InputSpace({'p_f1_LF','p_f2_LF'},[25, 25],[30, 30],[27, 28]);

    % bypass
    bypass                  = UnitClass();
    bypass.KEY              = 'bypass';
    bypass.FullName         = 'bypass';
    bypass.DesignSpace      = InputSpace({},[],[],[]);
    
    % Map of all units
    uKeys={};
    uValues={};
    w = whos; % Looks for all variables
    for i=1:length(w)
        if strcmp(w(i).class,'UnitClass')
            uKeys{end+1}=w(i).name;
            eval(sprintf('uValues{end+1}= %s;',w(i).name));
        end
    end
    uMap    = containers.Map(uKeys,uValues);
end
