% add the path to the models
addpath(genpath('../models'))

clc; clearvars;

%% Pretreatment
% d=4;   % dimensions
% N=500; % MC samples 
% 
% 
% % LHS
% Xp = rs_sample(N,d);
% figure; plotmatrix(Xp)
% 
% 
% % decision variables
% p.names = {'T','time','acid'};            
% p.lbs   = [173, 18, 0.5];    % lower bounds
% p.ubs   = [195, 30, 2.0];    % upper bounds
% 
% % Convert to real value space
% for i=1:numel(p.lbs), Xr(:,i) = unifinv(Xp(:,i),p.lbs(i),p.ubs(i)); end 
% 
% 
% Y = nk_process(Xr, 'pretreatment');
% data = [Xr Y];
% corrplot(data)
% save pretdata Y Xr p

%% Fermentation
% d=3;   % dimensions
% N=500; % MC samples 
% 
% 
% % LHS
% Xp = rs_sample(N,d);
% figure; plotmatrix(Xp)
% 
% 
% % decision variables
% p.names = {'time','inoculum'};            
% p.lbs   = [8, 0.5];    % lower bounds
% p.ubs   = [48, 3];    % upper bounds
% 
% % Convert to real value space
% for i=1:numel(p.lbs), Xr(:,i) = unifinv(Xp(:,i),p.lbs(i),p.ubs(i)); end 
% 
% 
% Y = nk_process(Xr, 'fermentation_xylitol');
% data = [Xr Y];
% corrplot(data)
% save pretdata Y Xr p

%% Evaporation
d=4;   % dimensions
N=3; % MC samples 


% LHS
Xp = rs_sample(N,d);
figure; plotmatrix(Xp)


% decision variables
p.names = {'time','vapor fraction','preheat temperature'};            
p.lbs   = [24, 0.9, 80];    % lower bounds
p.ubs   = [96, 0.99, 95];    % upper bounds

% Convert to real value space
for i=1:numel(p.lbs), Xr(:,i) = unifinv(Xp(:,i),p.lbs(i),p.ubs(i)); end 


Y = nk_process(Xr, 'evaporation_xylitol');
data = [Xr Y];
corrplot(data)
save pretdata Y Xr p

%% Crystallization
% d=5;   % dimensions
% N=500; % MC samples 
% 
% 
% % LHS
% Xp = rs_sample(N,d);
% figure; plotmatrix(Xp)
% 
% 
% % decision variables
% p.names = {'time','initial temperature','final temperature','antisolvent flowrate'};            
% p.lbs   = [2, 35, 10, 0.01];    % lower bounds
% p.ubs   = [12, 45, 15, 0.1];    % upper bounds
% 
% % Convert to real value space
% for i=1:numel(p.lbs), Xr(:,i) = unifinv(Xp(:,i),p.lbs(i),p.ubs(i)); end 
% 
% 
% Y = nk_process(Xr, 'crystallization_xylitol');
% data = [Xr Y];
% corrplot(data)
% save pretdata Y Xr p