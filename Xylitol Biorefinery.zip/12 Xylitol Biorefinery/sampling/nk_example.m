clc; clear;

[T, configIDs] = nk_ctable; 
cID = 7; 
configID = configIDs{cID}; 
space    = nk_designSpace(configID); show(space);
N        = 1e3;
X        = nk_sampleLHS(N,space.LowerBounds,space.UpperBounds)
