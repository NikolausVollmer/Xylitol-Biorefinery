
clc; clear;
addpath("../easyGSA")
addpath("../simulations")

N = 2000;
cIDs = [1,2,3,4,9,10,11,12,17,18,19,20,25,26,27,28];

for cID = cIDs
    % read MCS data

    Ti = readtable(sprintf("C%di_%d.csv",cID,N))
    To = readtable(sprintf("C%do_%d.csv",cID,N))

    % clean data
    T = [Ti To];
    T = rmmissing(T); % remove NaNs
%     T = rmoutliers(T,'quartiles'); % remove outliers


    %% perform GSA for the selected output
    output    = 'MSEP'; % select the output 
    threshold = 0.001;         % for removing unimportant decision variables

    Data.X = T{:,Ti.Properties.VariableNames}; % inputs
    Data.Y = T{:,output}; % output

    % GPRindicies
%     [gprSi,gprSTi,gpr_results] = easyGSA('UserData',Data) % uses GPR models by default.
%     gpr_results.GPRstats

    % ANNindices
    [annSi,annSTi,ann_results] = easyGSA('UserData',Data,'UseSurrogate','ANN')
    ann_results.ANNstats
    

%     S  = array2table([gprSi,annSi],"VariableNames",{'gprSi','annSi'},...
%                     "RowNames",Ti.Properties.VariableNames)
% 
%     ST = array2table([gprSTi,annSTi],"VariableNames",{'gprSTi','annSTi'},...
%                     "RowNames",Ti.Properties.VariableNames)

    S  = array2table([annSi],"VariableNames",{'annSi'},...
                    "RowNames",Ti.Properties.VariableNames)

    ST = array2table([annSTi],"VariableNames",{'annSTi'},...
                    "RowNames",Ti.Properties.VariableNames)


    fprintf("\nThe important decision variables for the output %s in configuration %d are the following:\n",output,cID)
    disp(S) % based on gprSTi
    disp(ST) % based on gprSTi

    % save table
    save(sprintf("c%d_GSA_%s",cID,output))

    
    writetable(S,sprintf("C%d_S_%s.csv",cID,output),'WriteRowNames',true)
    writetable(ST,sprintf("C%d_ST_%s.csv",cID,output),'WriteRowNames',true)
end
