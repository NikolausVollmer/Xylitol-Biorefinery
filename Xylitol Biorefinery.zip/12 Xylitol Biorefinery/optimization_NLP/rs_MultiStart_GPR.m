% design space optimization using GPR models with MultiStart/fmincon
% By Resul Al @DTU

clc; clear;

addpath("../modelling_GPR")
addpath("../simulations/N=500")
addpath("../simulations/N=1000")
addpath("../sampling")

cIDs = [1,3,4,9,11,12,17,19,20,25,27,28];
Ns = [500];


for e=1:length(Ns)
    for d=1:length(cIDs)
        
        cID = cIDs(d);
        N = Ns(e);

        load(sprintf("c%d_GPR_%d_opt",cID,N),'npvGPR','xyoGPR','sucGPR','pelGPR')
        load(sprintf("c%d_MCS",cID),'space') % load Input Space from MCS

        % play with the constraint limits
        m_xyo_annual = 227.8e6; % kg/y in 2021 (assuming 260e6kg in 2023 (see xylitol reviews) and annual growth of around 6.4%, https://www.grandviewresearch.com/press-release/global-xylitol-market)
        m_suc_annual = 71.8e6;  % kg/y in 2021 (assuming 94e6kg in 2025 (see Dickson 2021) and annual growth of 6.5%, Dickson et al. 2021)
        P_el_annual = 6892;   % MW in 07/2021 (see Energistyrelsen)
        clims = [0.05 * m_xyo_annual,...
                 0.2 * m_suc_annual,...
                 0.0005 * P_el_annual]; 

        objGPR = npvGPR;            
        con1GPR = xyoGPR;
        con2GPR = sucGPR;
        con3GPR = pelGPR;

        red = reduced_space(cID);

        %% Using MultiStart
        % https://se.mathworks.com/help/gads/how-globalsearch-and-multistart-work.html
        timer    = tic;
        x0       = (space.LowerBounds(red)+space.UpperBounds(red))/2; % replace with a better one
        lbs      = space.LowerBounds(red);
        ubs      = space.UpperBounds(red);

        % x0       = (x0 - muX)./sigX;
        % lbs      = (lbs - muX)./sigX;
        % ubs      = (ubs - muX)./sigX;

        fun      = @(x) -predict(objGPR,x); % objective for optimization, put minus for maximize 
        % cons     = @(x) deal([clims(1)-predict(con1GPR,x), clims(2) - predict(con2GPR,x), predict(con3GPR,x) - clims(3)],[]); % limits are imposed as <=

        cons     = @(x) deal([(clims(1) - predict(con1GPR,x)) * power(10,1-floor(log10(abs(clims(1) - predict(con1GPR,x))))),...
                              (clims(2) - predict(con2GPR,x)) * power(10,1-floor(log10(abs(clims(2) - predict(con2GPR,x))))),...
                              predict(con3GPR,x) - clims(3)],[]); % limits are imposed as <=
        opts     = optimoptions('fmincon','Display','None','Algorithm','sqp');
        problem  = createOptimProblem('fmincon','x0',x0,'lb',lbs,'ub',ubs,...
                  'objective',fun,'nonlcon',cons,'options',opts);

        ms       = MultiStart(); % 'UseParallel',true,'Display','none'
        [x,fval,exitflag,output] = run(ms,problem,1000)
        runtime = toc(timer)

        con1 = predict(con1GPR,x)
        con2 = predict(con2GPR,x)
        con3 = predict(con3GPR,x)
        % 
        % conditions = x.*sigX + muX
        % obj = -fval*sigyObj + muyObj
        % con1 = con1*sigyCon1 + muyCon1
        % con2 = con2*sigyCon2 + muyCon2
        % con3 = con3*sigyCon3 + muyCon3

        table(lbs', x', ubs','VariableNames',{'LowerBounds','OptFound','UpperBounds'},'RowNames',space.ParNames(red))
        save(sprintf("c%d_NLP_GPR_%d",cID,N))

    end
end

function red = reduced_space(cID)

red_cID1 = [9,21,25,27,29];
red_cID2 = [7,15,18,20,22];
red_cID3 = [8,19,24,25,27];
red_cID4 = [6,13,17,18,20];

red_cID9 = [9,21,26,27,28];
red_cID10 = [7,15,19,20,21];
red_cID11 = [8,19,23,25,26];
red_cID12 = [6,13,16,18,19];

red_cID17 = [8,19,23,25,27];
red_cID18 = [6,13,16,18,20];
red_cID19 = [7,17,22,23,25];
red_cID20 = [5,11,15,16,18];

red_cID25 = [8,19,24,25,26];
red_cID26 = [6,13,17,18,19];
red_cID27 = [7,17,22,23,24];
red_cID28 = [5,11,14,16,17];

red_0 = [0,0,0,0,0];

red_cID = [red_cID1;red_cID2;red_cID3;red_cID4;
           red_0;red_0;red_0;red_0;
           red_cID9;red_cID10;red_cID11;red_cID12;
           red_0;red_0;red_0;red_0;
           red_cID17;red_cID18;red_cID19;red_cID20;
           red_0;red_0;red_0;red_0;
           red_cID25;red_cID26;red_cID27;red_cID28;
           red_0;red_0;red_0;red_0];


red = red_cID(cID,:);

end